import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { apiReference } from '@scalar/nestjs-api-reference';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use((req, res, next) => {
    if (req.path.includes('/uploads/') || req.path.endsWith('.webp')) {
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    }
    next();
  });
  app.enableCors({
    origin: [
      'https://localhost:3000',
      'http://localhost:3000',
      'https://localhost:3001',
      'http://localhost:3001',
      'https://localhost:3002',
      'http://localhost:3002',
      'https://jetschool.az',
      'https://www.jetschool.az',
      'https://api.jetschool.az',
      'http://api.jetschool.az',
    ],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    allowedHeaders:
      'Origin,X-Requested-With,Content-Type,Accept,Authorization,Access-Control-Allow-Origin',
    credentials: true,
    preflightContinue: false,
    optionsSuccessStatus: 204,
  });

  // test
  app.setGlobalPrefix('api');
  const config = new DocumentBuilder()
    .setTitle('JET School API')
    .setDescription('API endpoints documentation')
    .setVersion('1.0')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        name: 'JWT',
        description: 'Enter JWT token',
        in: 'header',
      },
      'JWT-auth',
    )
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('docs', app, document, {
    useGlobalPrefix: true,
    jsonDocumentUrl: 'docs/swagger/json',
  });
  app.use(
    '/reference',
    apiReference({
      theme: 'deepSpace',
      spec: {
        url: 'api/docs/swagger/json',
      },
    }),
  );

  app.use('/robots.txt', (req, res) => {
    res.type('text/plain');
    res.send('User-agent: *\nDisallow: /uploads/\nDisallow: /*.webp$');
  });
  app.enableShutdownHooks();

  await app.listen(process.env.PORT || 3002);
}

bootstrap();
