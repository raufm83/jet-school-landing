export class Glossary {}
