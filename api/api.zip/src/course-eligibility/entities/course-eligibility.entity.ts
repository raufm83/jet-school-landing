export class CourseEligibility {}
