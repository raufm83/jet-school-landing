export class CourseTeacher {}
