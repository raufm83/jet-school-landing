import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsString, IsBoolean, IsOptional } from 'class-validator';

export class CreateCourseDto {
  @ApiProperty({ example: 'Full Stack Development' })
  @IsString()
  'title[az]': string;

  @ApiProperty({ example: 'Разработка Full Stack' })
  @IsString()
  'title[ru]': string;

  @ApiProperty({ example: 'Tam stack veb proqramlaşdırma kursu' })
  @IsString()
  'description[az]': string;

  @ApiProperty({ example: 'Курс веб-разработки полного стека' })
  @IsString()
  'description[ru]': string;

  @ApiProperty({ example: 'full-stack-development' })
  @IsString()
  'slug[az]': string;

  @ApiProperty({ example: 'razrabotka-full-stack' })
  @IsString()
  'slug[ru]': string;

  @ApiProperty({ example: 6 })
  @IsString()
  duration: number;

  @ApiProperty({ example: 'razrabotka-full-stack' })
  @IsString()
  'level[az]': string;

  @ApiProperty({ example: 'razrabotka-full-stack' })
  @IsString()
  'level[ru]': string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => value === 'true')
  published?: boolean;

  @ApiProperty({
    type: 'string',
    format: 'binary',
    required: false,
    description: 'Course image file',
  })
  @IsOptional()
  image?: any;
  imageUrl?: string;
}
