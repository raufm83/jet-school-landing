import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { ContactModule } from './contact/contact.module';
import { GalleryModule } from './gallery/gallery.module';
import { PrismaModule } from './prisma.module';
import { RequestModule } from './request/request.module';
import { StudentProjectModule } from './student-project/student-project.module';
import { TeamModule } from './team/team.module';
import { UserModule } from './user/user.module';
import { CourseModule } from './course/course.module';
import { CourseEligibilityModule } from './course-eligibility/course-eligibility.module';
import { CourseModuleModule } from './course-module/course-module.module';
import { CourseTeacherModule } from './course-teacher/course-teacher.module';
import { PostModule } from './post/post.module';
import { GlossaryModule } from './glossary/glossary.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: `.env`,
      isGlobal: true,
    }),
    PrismaModule,
    AuthModule,
    UserModule,
    RequestModule,
    StudentProjectModule,
    TeamModule,
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', 'uploads'),
      serveRoot: '/uploads',
    }),
    ContactModule,
    GalleryModule,
    CourseModule,
    CourseEligibilityModule,
    CourseModuleModule,
    CourseTeacherModule,
    PostModule,
    GlossaryModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
