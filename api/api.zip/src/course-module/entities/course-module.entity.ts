export class CourseModule {}
