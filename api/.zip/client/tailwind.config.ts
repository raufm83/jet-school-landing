import type { Config } from "tailwindcss";
import { nextui } from "@nextui-org/react";
import typography from "@tailwindcss/typography";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        jsyellow: "#FCAE1E",
        jsblack: "#1C1C1C",
      },
      boxShadow: {
        jsshadow: "0px 18px 18px rgba(140, 140, 140, 0.09)",
      },
      dropShadow: {
        jsshadow: ["0 18px 18px rgba(140, 140, 140, 0.09)"],
      },
      container: {
        center: true,
        screens: {
          sm: "100%",
          md: "100%",
          lg: "1240px",
          xl: "1240px",
        },
        padding: {
          DEFAULT: "1rem",
          md: "1.5rem",
          "min-1240px": "0",
        },
      },
      animation: {
        "fade-up": "fadeUp 0.5s ease-out forwards",
        fadeIn: "fadeIn 0.5s ease-out forwards",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeUp: {
          "0%": {
            opacity: "0",
            transform: "translateY(1rem)",
          },
          "100%": {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
      },
      scale: {
        "102": "1.02",
      },
    },
  },
  darkMode: "class",
  plugins: [nextui(), typography()],
};
export default config;
