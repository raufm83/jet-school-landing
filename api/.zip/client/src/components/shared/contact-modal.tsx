"use client";
import { useContactModal } from "@/hooks/useContactModal";
import { useTranslations } from "next-intl";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { MdClose, MdOutlineCheck } from "react-icons/md";
import { RequestFormInputs, Language } from "@/types/request";
import axios from "axios";
import api from "@/utils/api/axios";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import Select from "../ui/select";

export default function ContactModal() {
  const t = useTranslations("contact.form");
  const { isOpen, toggle } = useContactModal();
  const [success, setSuccess] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
    setValue,
  } = useForm<RequestFormInputs>();

  const ageOptions = Array.from({ length: 7 }, (_, i) => ({
    value: i + 9,
    label: `${i + 9}`,
  }));

  const languageOptions = [
    { value: Language.AZ, label: t("childLanguage.options.az") },
    { value: Language.RU, label: t("childLanguage.options.ru") },
  ];

  const onSubmit = handleSubmit((data) => {
    return toast.promise(api.post("/requests", data), {
      loading: t("sending"),
      success: () => {
        reset();
        setSuccess(true);
        return t("messageSent");
      },
      error: (err) => {
        if (axios.isAxiosError(err) && err.response) {
          return err.response.data.message || t("sendError");
        }
        return t("unexpectedError");
      },
      classNames: {
        icon: "text-jsyellow",
      },
    });
  });

  const handleAgeChange = (value: string | number) => {
    setValue("childAge", Number(value));
  };

  const handleLanguageChange = (value: string | number) => {
    setValue("childLanguage", value as Language);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed h-full w-full z-[999] flex items-center justify-center inset-0">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-jsblack/20"
            onClick={toggle}
          />
          {success && (
            <motion.div
              className="absolute z-10 bg-white rounded-[32px] p-6 w-full max-w-[500px] mx-4 flex flex-col items-center justify-center space-y-4"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 ml-auto hover:bg-jsyellow/10 rounded-full"
                onClick={() => {
                  reset();
                  toggle();
                }}
                type="button"
              >
                <MdClose className="text-xl" />
              </motion.button>
              <div className="flex items-center justify-between mb-6">
                <h1 className="font-semibold text-lg text-jsblack">
                  {t("messageSent")}
                </h1>
              </div>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{
                  type: "spring",
                  stiffness: 260,
                  damping: 20,
                  delay: 0.2,
                }}
                className="bg-green-100 rounded-full p-3"
              >
                <MdOutlineCheck className="text-green-600 text-3xl" />
              </motion.div>
            </motion.div>
          )}
          {!success && (
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="relative bg-white rounded-[32px]  w-full max-w-[500px] mx-4 p-6 space-y-6"
              onSubmit={onSubmit}
            >
              <div className="flex items-center justify-between mb-6">
                <h1 className="font-semibold text-xl text-jsblack">
                  {t("title")}
                </h1>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-2 hover:bg-jsyellow/10 rounded-full"
                  onClick={() => {
                    reset();
                    toggle();
                  }}
                  type="button"
                >
                  <MdClose className="text-xl" />
                </motion.button>
              </div>

              <div className="space-y-2">
                <input
                  type="text"
                  placeholder={t("name.placeholder")}
                  className="w-full p-4 rounded-[32px] border border-jsyellow bg-[#fef7eb] 
                  focus:outline-none focus:ring-2 focus:ring-jsyellow 
                  shadow-sm transition-all duration-300 ease-in-out"
                  {...register("name", {
                    required: t("name.required"),
                    minLength: {
                      value: 2,
                      message: t("name.minLength"),
                    },
                  })}
                />
                {errors.name && (
                  <p className="text-red-500 text-sm pl-2">
                    {errors.name.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <input
                  type="text"
                  placeholder={t("surname.placeholder")}
                  className="w-full p-4 rounded-[32px] border border-jsyellow bg-[#fef7eb] 
                  focus:outline-none focus:ring-2 focus:ring-jsyellow 
                  shadow-sm transition-all duration-300 ease-in-out"
                  {...register("surname", {
                    required: t("surname.required"),
                    minLength: {
                      value: 2,
                      message: t("surname.minLength"),
                    },
                  })}
                />
                {errors.surname && (
                  <p className="text-red-500 text-sm pl-2">
                    {errors.surname.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <input
                  type="tel"
                  placeholder={t("number.placeholder")}
                  className="w-full p-4 rounded-[32px] border border-jsyellow bg-[#fef7eb] 
                  focus:outline-none focus:ring-2 focus:ring-jsyellow 
                  shadow-sm transition-all duration-300 ease-in-out"
                  {...register("number", {
                    required: t("number.required"),
                    pattern: {
                      value: /^(\+994|0)(50|51|55|70|77|99|10)\d{7}$/,
                      message: t("number.invalid"),
                    },
                  })}
                />
                {errors.number && (
                  <p className="text-red-500 text-sm pl-2">
                    {errors.number.message}
                  </p>
                )}
              </div>

              <Select
                label={t("childAge.label")}
                description={t("childAge.description")}
                options={ageOptions}
                error={errors.childAge}
                placeholder={t("childAge.placeholder")}
                {...register("childAge", {
                  required: t("childAge.required"),
                })}
                onChange={handleAgeChange}
              />

              <Select
                label={t("childLanguage.label")}
                options={languageOptions}
                error={errors.childLanguage}
                placeholder={t("childLanguage.placeholder")}
                {...register("childLanguage", {
                  required: t("childLanguage.required"),
                })}
                onChange={handleLanguageChange}
              />

              <motion.button
                type="submit"
                className="w-full bg-jsyellow text-white font-semibold py-4 px-8 
                rounded-[32px] hover:bg-jsyellow/90 disabled:opacity-50 
                transition-all duration-300 ease-in-out shadow-md"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={isSubmitting}
              >
                {isSubmitting ? t("sending") : t("submit")}
              </motion.button>
            </motion.form>
          )}
        </div>
      )}
    </AnimatePresence>
  );
}
