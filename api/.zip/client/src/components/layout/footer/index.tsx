import { ContactData } from "@/types/contact";
import { getContact } from "@/utils/api/contact";
import { getLocale, getTranslations } from "next-intl/server";
import Image from "next/image";
import Link from "next/link";
import {
  FaClock,
  FaEnvelope,
  FaFacebook,
  FaInstagram,
  FaMapMarkerAlt,
  FaPhone,
  FaWhatsapp,
  FaYoutube,
} from "react-icons/fa";
import { FaTiktok } from "react-icons/fa6";
import api from "@/utils/api/axios";

// Kurs veri tipini tanımla
interface Course {
  id: string;
  title: {
    az: string;
    ru: string;
  };
  slug: {
    az: string;
    ru: string;
  };
  createdAt: string;
}

// API yanıt tipi
interface CoursesResponse {
  items?: Course[];
}

// Kurs verilerini almak için fetchCourses fonksiyonu
const fetchCourses = async (): Promise<CoursesResponse | Course[] | null> => {
  try {
    const response = await api.get("/courses");
    return response.data;
  } catch (error) {
    console.error("Failed to fetch courses:", error);
    return null;
  }
};

const Footer = async () => {
  try {
    const t = await getTranslations("footer");
    const locale = await getLocale();
    const contact: ContactData = await getContact();
    const coursesData = await fetchCourses();
    const currentYear = new Date().getFullYear();

    // Kursları yeniden eskiye sırala
    const sortedCourses: Course[] = Array.isArray(coursesData)
      ? coursesData.slice().sort((a: Course, b: Course) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      : coursesData?.items
      ? coursesData.items.slice().sort((a: Course, b: Course) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      : [];

    return (
      <footer
        id="contacts"
        className="bg-jsyellow w-screen relative text-white mt-16 md:mt-20"
      >
        {/* Background images */}
        <div className="absolute z-[0] opacity-50 blur-[2px] right-0 top-[10%] md:-left-[5%] mix-blend-soft-light md:top-0">
          <Image width={300} height={300} src="/hero/rocket.png" alt="" className="w-[200px] md:w-[300px]" />
        </div>
        <div className="absolute z-[0] opacity-60 blur-[2px] right-0 top-1/2 md:-right-[5%] mix-blend-soft-light md:top-4">
          <Image width={300} height={300} src="/hero/book.png" alt="" className="w-[200px] md:w-[300px]" />
        </div>
        <div className="absolute z-[0] opacity-70 hidden md:block blur-[2px] left-[20%] mix-blend-soft-light bottom-4">
          <Image width={300} height={300} src="/hero/laptop.png" alt="" className="w-[200px] md:w-[300px]" />
        </div>

        <div className="container relative z-[2] py-8 md:py-12 lg:py-16">
          <div className="grid grid-cols-1 md:grid-cols-[2fr_3fr] gap-6 md:gap-8 lg:gap-12">
            {/* Left Column - Contact Info */}
            <div className="flex flex-col gap-4 md:gap-6">
              <div className="flex flex-col gap-2">
                <h2 className="text-2xl md:text-3xl font-bold">JET School</h2>
                <p className="text-white/80 text-sm md:text-base max-w-xs md:max-w-sm">
                  {t("tagline") || "Inspiring education for a brighter future"}
                </p>
              </div>

              <div className="flex flex-col gap-4 md:gap-5">
                <Link
                  href={`https://maps.google.com?q=${encodeURIComponent(
                    contact.address[locale as keyof typeof contact.address]
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 md:gap-3 hover:underline text-sm md:text-base"
                >
                  <FaMapMarkerAlt className="w-4 h-4 md:w-5 md:h-5 shrink-0" />
                  <p>{contact.address[locale as keyof typeof contact.address]}</p>
                </Link>

                <Link
                  href={`https://maps.google.com?q=${encodeURIComponent(
                    contact.address2[locale as keyof typeof contact.address2]
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 md:gap-3 hover:underline text-sm md:text-base"
                >
                  <FaMapMarkerAlt className="w-4 h-4 md:w-5 md:h-5 shrink-0" />
                  <p>{contact.address2[locale as keyof typeof contact.address2]}</p>
                </Link>

                <div className="flex flex-col gap-2 md:gap-3">
                  <Link
                    href={`tel:${contact.phone.replace(/\D/g, "")}`}
                    className="flex items-center gap-2 md:gap-3 hover:underline text-sm md:text-base"
                  >
                    <FaPhone className="w-4 h-4 md:w-5 md:h-5 shrink-0" />
                    <p>{contact.phone}</p>
                  </Link>
                  <Link
                    href={`https://wa.me/${contact.whatsapp.replace(/\D/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 md:gap-3 hover:underline text-sm md:text-base"
                  >
                    <FaWhatsapp className="w-4 h-4 md:w-5 md:h-5 shrink-0" />
                    <p>{contact.whatsapp}</p>
                  </Link>
                  <Link
                    href={`mailto:${contact.email || "info@jetschool.az"}`}
                    className="flex items-center gap-2 md:gap-3 hover:underline text-sm md:text-base"
                  >
                    <FaEnvelope className="w-4 h-4 md:w-5 md:h-5 shrink-0" />
                    <p>{contact.email || "info@jetschool.az"}</p>
                  </Link>
                </div>

                <div className="flex items-start gap-2 md:gap-3">
                  <FaClock className="w-4 h-4 md:w-5 md:h-5 mt-1 sm:mt-0 shrink-0" />
                  <div className="flex flex-col gap-2 text-sm md:text-base">
                    <p>
                      {contact.workingHours[locale as keyof typeof contact.workingHours].weekdays}
                    </p>
                    <p>
                      {contact.workingHours[locale as keyof typeof contact.workingHours].sunday}
                    </p>
                  </div>
                </div>

                {/* Social Media Links */}
                <div className="flex gap-3 mt-2">
                  <Link
                    href="https://www.facebook.com/jetschool.az/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                  >
                    <FaFacebook className="w-4 h-4 md:w-5 md:h-5" />
                  </Link>
                  <Link
                    href="https://instagram.com/jet.school.baku"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                  >
                    <FaInstagram className="w-4 h-4 md:w-5 md:h-5" />
                  </Link>
                  <Link
                    href="https://youtube.com/@jetschoolbaku"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                  >
                    <FaYoutube className="w-4 h-4 md:w-5 md:h-5" />
                  </Link>
                  <Link
                    href="https://www.tiktok.com/@jetschoolbaku"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                  >
                    <FaTiktok className="w-4 h-4 md:w-5 md:h-5" />
                  </Link>
                </div>
              </div>
            </div>

            {/* Right Column - Maps & Quick Links */}
            <div className="flex flex-col gap-6 md:gap-8">
              {/* Quick Links Section */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                <div className="flex flex-col gap-3">
                  <h3 className="text-lg md:text-xl font-bold">{t("explore") || "Explore"}</h3>
                  <ul className="flex flex-col gap-1.5 md:gap-2">
                    <li>
                      <Link
                        href="/"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("home") || "Home"}
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/about-us"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("about") || "About Us"}
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/gallery"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("gallery") || "Gallery"}
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/blog"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("blog") || "Blog"}
                      </Link>
                    </li>
                  </ul>
                </div>
                <div className="flex flex-col gap-3">
                  <h3 className="text-lg md:text-xl font-bold">{t("courses") || "Kurslar"}</h3>
                  <ul className="flex flex-col gap-1.5 md:gap-2">
                    {sortedCourses.length > 0 ? (
                      sortedCourses.map((course) => (
                        <li key={course.id}>
                          <Link
                            href={`/courses/${course.slug[locale as keyof typeof course.slug]}`}
                            className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                          >
                            {course.title[locale as keyof typeof course.title] || "Course"}
                          </Link>
                        </li>
                      ))
                    ) : (
                      <li>
                        <p className="text-sm md:text-base">{t("noCourses") || "No courses available"}</p>
                      </li>
                    )}
                  </ul>
                </div>
                <div className="flex flex-col gap-3">
                  <h3 className="text-lg md:text-xl font-bold">{t("resources") || "Resources"}</h3>
                  <ul className="flex flex-col gap-1.5 md:gap-2">
                    <li>
                      <Link
                        href="/glossary"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("glossary") || "Glossary"}
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/news"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("news") || "News"}
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/projects"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("projects") || "Projects"}
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/contact-us"
                        className="hover:underline transition-all hover:translate-x-1 inline-block text-sm md:text-base"
                      >
                        {t("contact") || "Contact"}
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Maps Section */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="min-h-[200px] sm:h-[250px] md:h-[280px] w-full rounded-2xl overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3038.295492488534!2d49.85321957640148!3d40.398504156747784!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40306351d4b38089%3A0xb74ef857d0a65d43!2sJET%20Academy%20Genclik!5e0!3m2!1sru!2saz!4v1731422632545!5m2!1sru!2saz"
                    className="w-full h-full border-0"
                    allowFullScreen={false}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>
                <div className="min-h-[200px] sm:h-[250px] md:h-[280px] w-full rounded-2xl overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1519.7064589245335!2d49.874345249297455!3d40.38476849212484!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4030635c979bcb1d%3A0xfa39683687982543!2sJET%20Academy%20Xetai!5e0!3m2!1sru!2saz!4v1732715727560!5m2!1sru!2saz"
                    className="w-full h-full border-0"
                    allowFullScreen={false}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 md:mt-8 pt-6 md:pt-8 border-t border-white/20 text-center">
            <p className="text-sm md:text-base">
              © {currentYear} JET School. {t("copyright")}
            </p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error("Error loading footer data:", error);
    return (
      <footer className="bg-jsyellow w-screen relative text-white mt-16 py-6">
        <div className="container text-center">
          <p className="text-sm">© {new Date().getFullYear()} JET School</p>
        </div>
      </footer>
    );
  }
};

export default Footer;