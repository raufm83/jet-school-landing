"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { motion, AnimatePresence } from "framer-motion";
import { HiOutlinePhone } from "react-icons/hi2";
import { HiMenuAlt3, HiX } from "react-icons/hi";

import Logo from "./logo";
import NavLink from "./nav-link";
import Button from "@/components/ui/button";
import LanguageSwitcher from "@/components/shared/language-switcher";
import { useContactModal } from "@/hooks/useContactModal";
import { getNavLinks } from "@/data/navlinks";
import { usePathname } from "@/i18n/routing";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { toggle } = useContactModal();
  const t = useTranslations("navbar");
  const navLinks = getNavLinks(t);

  const path = usePathname();
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflowY = "hidden";
    } else {
      document.body.style.overflowY = "auto";
    }

    return () => {
      document.body.style.overflowY = "auto";
    };
  }, [isMenuOpen]);

  return (
    <header className="transition-all relative z-[999] pt-10 duration-300">
      <nav className="container flex justify-between items-center">
        <Link href="/" className="relative z-[51]">
          <Logo />
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center gap-8">
          <menu className="flex gap-6 items-center text-base font-medium text-jsblack">
            {navLinks.map((link) => (
              <NavLink
                isActive={path === link.href}
                key={link.title}
                {...link}
                handleClick={() => setIsMenuOpen(false)}
              />
            ))}
          </menu>

          <div className="flex gap-4 items-center">
            <LanguageSwitcher />
            <Button
              onClick={() => {
                setIsMenuOpen(false);
                toggle();
              }}
              icon={<HiOutlinePhone size={18} />}
              className="font-medium text-sm h-10 px-5 bg-jsyellow hover:bg-[#25d366] hover:text-white  text-white"
              text={t("contactus")}
            />
          </div>
        </div>

        {/* Mobile: LanguageSwitcher + Menu Toggle */}
        <div className="flex items-center gap-2 lg:hidden relative z-[51]">
          <LanguageSwitcher />
          <button
            onClick={toggleMenu}
            className="p-2 text-jsblack hover:bg-gray-100 rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <HiX size={24} /> : <HiMenuAlt3 size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-white z-[49] lg:hidden pt-20"
            >
              <div className="container py-6">
                <div className="flex flex-col gap-3">
                  {navLinks.map((link) => (
                    <NavLink
                      key={link.title}
                      {...link}
                      handleClick={() => setIsMenuOpen(false)}
                      className="text-lg py-3 border-b border-gray-100 cursor-pointer"
                    />
                  ))}
                </div>

                <div className="mt-8 flex flex-col gap-4">
                  <Button
                    onClick={() => {
                      setIsMenuOpen(false);
                      toggle();
                    }}
                    icon={<HiOutlinePhone size={20} />}
                    className="font-medium w-full bg-jsyellow   text-white"
                    text={t("contactus")}
                  />
                  <div className="flex justify-center mt-2"></div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
}
