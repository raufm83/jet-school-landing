import Image from "next/image";
import React from "react";

export default function Logo() {
  return (
    <div className="w-48 h-10 relative z-[52]">
      <Image
        alt="Logo of jet school"
        fill
        className="object-cover"
        src={"/logos/JET_School_Yellowww.png"}
      />
    </div>
  );
}
