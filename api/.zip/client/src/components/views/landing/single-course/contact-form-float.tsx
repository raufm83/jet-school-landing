"use client";
import { motion } from "framer-motion";
import { useTranslations } from "next-intl";
import ContactForm from "../contact-us/contact-form";

export default function ContactFormFloat() {
  const t = useTranslations("singleCoursePage");
  return (
    <motion.div
      className="bg-white border border-jsyellow rounded-[32px] p-8"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="text-2xl font-semibold text-jsblack mb-6">
        {t("enroll")}
      </h3>
      <ContactForm />
    </motion.div>
  );
}
