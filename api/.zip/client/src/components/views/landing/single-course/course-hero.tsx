interface CourseHeroProps {
  title: string;
  duration: string;
  level: string;
  description: string;
  courseOverviewText: string;
  tags?: string[];
}

export default function CourseHero({
  title,
  duration,
  level,
  description,
  courseOverviewText,
  tags = [],
}: CourseHeroProps) {
  return (
    <div className="flex flex-col gap-6 animate-fadeIn">
      <div className="flex items-center gap-4">
        <span className="bg-jsyellow/10 text-jsblack px-4 py-2 rounded-full">
          {duration}
        </span>
        <span className="bg-jsyellow/10 text-jsblack px-4 py-2 rounded-full">
          {level}
        </span>
      </div>

      <h2 className="text-5xl font-bold leading-[1.3] text-jsblack">{title}</h2>

      {tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, index) => (
            <span
              key={index}
              className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
            >
              {tag}
            </span>
          ))}
        </div>
      )}

      <div className="bg-[#fef7eb] border border-jsyellow rounded-[32px] p-6 transition-all duration-300 hover:scale-[1.01] hover:shadow-lg">
        <p className="font-semibold text-xl mb-4">{courseOverviewText}</p>
        <div
          dangerouslySetInnerHTML={{ __html: description }}
          className="text-gray-600 prose-li:list-disc prose-li:ml-4"
        ></div>
      </div>
    </div>
  );
}
