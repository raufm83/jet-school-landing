"use client";
import { CourseModule } from "@/types/course";
import { useState } from "react";

interface CourseContentProps {
  modules: CourseModule[];
  locale: "az" | "ru";
  title: string;
}

export default function CourseContent({
  modules,
  locale,
  title,
}: CourseContentProps) {
  const [openModule, setOpenModule] = useState<number | null>(0);

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">{title}</h2>
      <div className="space-y-4">
        {modules.map((module, index) => (
          <div
            key={index}
            className="border border-jsyellow rounded-[32px] overflow-hidden"
          >
            <button
              className="w-full p-6 flex justify-between items-center bg-[#fef7eb] text-left"
              onClick={() => setOpenModule(openModule === index ? null : index)}
            >
              <div className="flex items-center">
                <div className="w-6 h-6 bg-jsyellow text-white flex items-center justify-center mr-4 rounded-full">
                  {index + 1}
                </div>
                <span className="font-semibold">
                  {module.module.title[locale]}
                </span>
              </div>
              <span
                className={`transform transition-transform duration-200 ${
                  openModule === index ? "rotate-180" : "rotate-0"
                }`}
              >
                ↓
              </span>
            </button>
            <div
              className={`transition-all duration-300 overflow-hidden ${
                openModule === index ? "max-h-96" : "max-h-0"
              }`}
            >
              <div className="p-6 bg-white">
                <ul className="list-disc list-inside space-y-2">
                  {module.module.content.map((item, idx) => (
                    <li key={idx}>{item[locale]}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
