"use client";

import { getRelatedPosts, getAllPosts } from "@/utils/api/post";
import { Post } from "@/types/post";
import { Locale } from "@/i18n/request";
import { PostType } from "@/types/enums";
import { useEffect, useState } from "react";
import { formatDateTime } from "@/utils/formatters/formatDate";
import { useTranslations } from "next-intl";
import Link from "next/link";
import Image from "next/image";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";

interface RelatedPostsProps {
  title: string;
  locale: Locale;
  currentPostId: string;
  postType: PostType;
  tags: string[];
}

export default function RelatedPosts({
  title,
  locale,
  currentPostId,
  postType,
  tags,
}: RelatedPostsProps) {
  const t = useTranslations("blogPage");
  const [relatedPosts, setRelatedPosts] = useState<Post[]>([]);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const result = await getRelatedPosts({
          postId: currentPostId,
          postType,
          tags,
          limit: 6,
        });


        const filteredResult = result.filter((post) => post.postType === PostType.BLOG);

        if (filteredResult.length === 0) {
          const fallback = await getAllPosts({
            page: 1,
            limit: 6,
            postType: PostType.BLOG,
          });

          const fallbackFiltered = fallback.items.filter(
            (post) => post.id !== currentPostId && post.postType === PostType.BLOG
          );
          setRelatedPosts(fallbackFiltered);
        } else {
          setRelatedPosts(filteredResult);
        }
      } catch (error) {
        console.error("RelatedPosts fetch error:", error);
      }
    };

    fetchPosts();
  }, [currentPostId, postType, tags, locale]);

  if (relatedPosts.length === 0) {
    return (
      <p className="text-gray-500 mt-6">
        {t("noPostsFound") || "No related posts available"}
      </p>
    );
  }

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-semibold mb-6">{title}</h2>
      <Swiper
        spaceBetween={24}
        slidesPerView={1.2}
        breakpoints={{
          640: { slidesPerView: 1.2 },
          768: { slidesPerView: 2 },
          1024: { slidesPerView: 2 },
        }}
      >
        {relatedPosts.map((post) => (
          <SwiperSlide key={post.id}>
            <div className="h-full">
              <RelatedPostCard post={post} locale={locale} t={t} />
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

interface RelatedPostCardProps {
  post: Post;
  locale: Locale;
  t: (key: string) => string;
}

function RelatedPostCard({ post, locale, t }: RelatedPostCardProps) {
  const formattedDate = formatDateTime(post.createdAt);

  const getPostTypeLabel = (type: PostType) => {
    switch (type) {
      case PostType.BLOG:
        return t("blog");
      case PostType.NEWS:
        return t("news");
      case PostType.EVENT:
        return t("event");
      case PostType.OFFERS:
        return t("offers");
      default:
        return type;
    }
  };

  const contentPreview =
    (post.content?.[locale]?.replace(/<[^>]*>/g, "")?.slice(0, 100) ?? "") + "...";

  const postUrl = post.slug[locale]
    ? `/news/${post.slug[locale]}`
    : `/news/${post.slug["az"] || post.id}`;

  const readMoreText =
    t("readMore") || (locale === "az" ? "Daha çox oxu" : "Читать далее");

  return (
    <Link
      href={postUrl}
      className="bg-[#fef7eb] border border-jsyellow rounded-[32px] overflow-hidden 
        transition-transform duration-300  hover:shadow-lg 
        hover:shadow-[rgba(252,174,30,0.15)] flex flex-col  h-full min-h-[450px]"
    >
      {post.imageUrl && (
        <div className="w-full relative h-[200px] overflow-hidden">
          <Image
            src={`${process.env.NEXT_PUBLIC_CDN_URL}/${post.imageUrl}`}
            alt={post.title[locale] || "Post image"}
            fill
            className="object-cover"
          />
        </div>
      )}
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-center mb-3">
          <span className="text-xs font-medium text-gray-500">{formattedDate}</span>
          <span
            className={`text-xs px-2 py-1 rounded-full ${
              post.postType === PostType.BLOG
                ? "bg-blue-100 text-blue-800"
                : post.postType === PostType.NEWS
                ? "bg-green-100 text-green-800"
                : post.postType === PostType.EVENT
                ? "bg-purple-100 text-purple-800"
                : post.postType === PostType.OFFERS
                ? "bg-yellow-100 text-yellow-800"
                : "bg-gray-100 text-gray-800"
            }`}
          >
            {getPostTypeLabel(post.postType)}
          </span>
        </div>
        <h3 className="font-semibold text-xl mb-3 line-clamp-2">
          {post.title[locale] || "Title not available"}
        </h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-3 flex-grow">{contentPreview}</p>
        <span className="text-jsyellow font-medium hover:underline">{readMoreText} →</span>
      </div>
    </Link>
  );
}
