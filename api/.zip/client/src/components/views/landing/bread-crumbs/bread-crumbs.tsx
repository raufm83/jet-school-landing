'use client';

import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import Link from 'next/link';

export default function Breadcrumbs() {
  const pathname = usePathname();
  const t = useTranslations(); // Hook'u en üstte, koşulsuz çağır
  const segments = pathname.split('/').filter(Boolean);

  if (segments.length === 0) return null;

  const locale = segments[0];
  const isMultilang = ['az', 'ru'].includes(locale);

  if (segments.length === 1 && isMultilang) return null;

  const filteredSegments = isMultilang ? segments.slice(1) : segments;

  // ❗️SINGLE PAGE mantığı: /courses/[slug] gibi 2 segment varsa sadece ilkini göster
  const isSinglePage = filteredSegments.length === 2;

  // Eğer single page'se sadece ilk segmenti al
  const segmentsToRender = isSinglePage ? [filteredSegments[0]] : filteredSegments;

  return (
    <nav className="p-4 text-sm text-gray-700 flex gap-1 items-center">
      <Link href={isMultilang ? `/${locale}` : '/'}>
        {t('home')}
      </Link>

      {segmentsToRender.map((segment, index) => {
        const href =
          '/' + segments.slice(0, index + (isMultilang ? 2 : 1)).join('/');

        const labelKey = segment.toLowerCase();
        let label: string;

        try {
          label = t(`breadcrumbs.${labelKey}`);
        } catch {
          label = decodeURIComponent(labelKey)
            .replace(/-/g, ' ')
            .replace(/\b\w/g, c => c.toUpperCase());
        }

        return (
          <span key={href} className="flex items-center gap-1">
            <span>&gt;</span>
            <Link href={href} className="transition-colors">
              {label}
            </Link>
          </span>
        );
      })}
    </nav>
  );
}