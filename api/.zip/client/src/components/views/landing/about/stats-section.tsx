"use client";
import { motion } from "framer-motion";

interface StatsProps {
  stats: {
    graduatesLabel: string;
    groupsLabel: string;
    studentsLabel: string;
  };
}

export default function StatsSection({ stats }: StatsProps) {
  return (
    <section className="container">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { value: "500+", label: stats.graduatesLabel },
          { value: "25+", label: stats.groupsLabel },
          { value: "200+", label: stats.studentsLabel },
        ].map(({ value, label }, index) => (
          <motion.div
            key={index}
            className="text-center p-8 bg-[#fef7eb] rounded-[32px] border border-jsyellow"
            whileHover={{ scale: 1.02 }}
          >
            <h3 className="text-4xl font-bold text-jsyellow mb-2">{value}</h3>
            <p className="text-gray-600">{label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
