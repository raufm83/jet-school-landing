"use client";

import { Language, RequestFormInputs } from "@/types/request";
import { motion } from "framer-motion";
import { useTranslations } from "next-intl";
import { SubmitHandler, useForm } from "react-hook-form";
import { toast } from "sonner";
import axios, { AxiosError } from "axios";
import api from "@/utils/api/axios";
import Select from "@/components/ui/select";

const ageOptions = Array.from({ length: 7 }, (_, i) => ({
  value: i + 9,
  label: `${i + 9}`,
}));

const ContactForm = () => {
  const t = useTranslations("contact.form");

  const languageOptions = [
    { value: Language.AZ, label: t("childLanguage.options.az") },
    { value: Language.RU, label: t("childLanguage.options.ru") },
  ];

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
    setValue,
  } = useForm<RequestFormInputs>();

  const onSubmit: SubmitHandler<RequestFormInputs> = async (data) => {
    try {
      await toast.promise(api.post("/requests", data), {
        loading: t("sending"),
        success: () => {
          reset();
          return t("messageSent");
        },
        error: (err: unknown) => {
          if (axios.isAxiosError(err)) {
            const error = err as AxiosError<any>;
            return error.response?.data.message || t("sendError");
          }
          return t("unexpectedError");
        },
        classNames: {
          icon: "text-jsyellow",
        },
      });
    } catch (err) {
      console.error("Error sending message:", err);
      toast.error(t("unexpectedError"));
    }
  };

  const handleAgeChange = (value: string | number) => {
    setValue("childAge", Number(value));
  };

  const handleLanguageChange = (value: string | number) => {
    setValue("childLanguage", value as Language);
  };

  return (
    <motion.form
      className="space-y-6 w-full"
      onSubmit={handleSubmit(onSubmit)}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
    >
      <div className="space-y-2">
        <input
          type="text"
          placeholder={t("name.placeholder")}
          className="w-full p-4 rounded-[32px] border border-jsyellow bg-[#fef7eb] 
            focus:outline-none focus:ring-2 focus:ring-jsyellow 
            shadow-sm transition-all duration-300 ease-in-out"
          {...register("name", {
            required: t("name.required"),
            minLength: {
              value: 2,
              message: t("name.minLength"),
            },
          })}
        />
        {errors.name && (
          <p className="text-red-500 text-sm pl-2">{errors.name.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <input
          type="text"
          placeholder={t("surname.placeholder")}
          className="w-full p-4 rounded-[32px] border border-jsyellow bg-[#fef7eb] 
            focus:outline-none focus:ring-2 focus:ring-jsyellow 
            shadow-sm transition-all duration-300 ease-in-out"
          {...register("surname", {
            required: t("surname.required"),
            minLength: {
              value: 2,
              message: t("surname.minLength"),
            },
          })}
        />
        {errors.surname && (
          <p className="text-red-500 text-sm pl-2">{errors.surname.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <input
          type="tel"
          placeholder={t("number.placeholder")}
          className="w-full p-4 rounded-[32px] border border-jsyellow bg-[#fef7eb] 
            focus:outline-none focus:ring-2 focus:ring-jsyellow 
            shadow-sm transition-all duration-300 ease-in-out"
          {...register("number", {
            required: t("number.required"),
            pattern: {
              value: /^(\+994|0)(50|51|55|70|77|99|10)\d{7}$/,
              message: t("number.invalid"),
            },
          })}
        />
        {errors.number && (
          <p className="text-red-500 text-sm pl-2">{errors.number.message}</p>
        )}
      </div>

      <Select
        label={t("childAge.label")}
        options={ageOptions}
        error={errors.childAge}
        placeholder={t("childAge.placeholder")}
        {...register("childAge", {
          required: t("childAge.required"),
        })}
        onChange={handleAgeChange}
      />

      <Select
        label={t("childLanguage.label")}
        options={languageOptions}
        error={errors.childLanguage}
        placeholder={t("childLanguage.placeholder")}
        {...register("childLanguage", {
          required: t("childLanguage.required"),
        })}
        onChange={handleLanguageChange}
      />

      <motion.button
        type="submit"
        className="w-full bg-jsyellow text-white font-semibold py-4 px-8 
          rounded-[32px] hover:bg-jsyellow/90 disabled:opacity-50 
          transition-all duration-300 ease-in-out shadow-md"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        disabled={isSubmitting}
      >
        {isSubmitting ? t("sending") : t("submit")}
      </motion.button>
    </motion.form>
  );
};

export default ContactForm;
