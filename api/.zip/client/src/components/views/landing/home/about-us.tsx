import SectionTitle from "@/components/shared/section-title";
import { getAboutPoints } from "@/data/info";
import { getTranslations } from "next-intl/server";
import React from "react";

async function AboutUs() {
  const t = await getTranslations("about");
  const aboutPoints = getAboutPoints(t);

  return (
    <div id="about" className="container my-20 flex flex-col gap-8">
      <SectionTitle title={t("title")} description={t("description")} />
      <div className="flex flex-col gap-4 relative">
        {aboutPoints.map((point, index) => (
          <div
            key={index}
            className={`w-full border sticky flex items-start gap-4 bg-white border-jsyellow rounded-[32px] p-6 text-jsblack ${point.position}`}
            style={{
              top: `${point.top}px`,
            }}
          >
            <div className="bg-jsyellow text-white font-bold flex items-center justify-center text-xl rounded-full h-10 w-10 min-h-10 min-w-10">
              {index + 1}
            </div>
            <div className="flex gap-4 flex-col">
              <h1 className="font-semibold text-[28px]">{point.title}</h1>
              <p>{point.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AboutUs;
