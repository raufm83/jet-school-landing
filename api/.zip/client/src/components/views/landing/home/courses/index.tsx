"use client";

import { useEffect, useState } from "react";
import SectionTitle from "@/components/shared/section-title";
import { Locale } from "@/i18n/request";
import { Course, CourseResponse } from "@/types/course";
import { getIcon } from "@/utils/icon";
import Link from "next/link";
import { FaClock, FaGraduationCap } from "react-icons/fa";
import { useTranslations } from "next-intl";

interface ICoursesSlider {
  courses: CourseResponse;
  locale?: Locale;
}

const CoursesSlider = ({ courses, locale = "az" }: ICoursesSlider) => {
  const t = useTranslations("courseInfo");
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const displayCourses = courses.items;
  if (!displayCourses) {
    return null;
  }

  return (
    <div className="container my-20 flex flex-col gap-8">
      <SectionTitle title={t("title")} description={t("description")} />

      <div className="relative">
        {isClient ? (
          <div
            className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4"
            style={{
              opacity: 1,
              transition: "opacity 0.3s ease",
            }}
          >
            {displayCourses.map((course: Course) => {
              const IconComponent = getIcon(course.icon);

              return (
                <div key={course.id} className="flex  items-center">
                  <Link
                    href={`/${locale}/course/${course.slug[locale]}`}
                    className="relative flex h-full w-full bg-[#fef7eb] border-2 border-jsyellow flex-col justify-between rounded-[32px] overflow-hidden"
                  >
                    <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-jsyellow/10 to-transparent" />

                    <div className="relative p-6 flex  h-full justify-between flex-col gap-6">
                      <div className="flex justify-end">
                        <div className="flex items-center gap-2 bg-white border border-jsyellow/20 px-4 py-2 rounded-full">
                          <FaGraduationCap className="w-4 h-4 text-jsyellow" />
                          <span className="text-sm font-medium text-jsblack">
                            {course.level[locale]}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-12 h-12 bg-jsyellow text-white rounded-2xl flex items-center justify-center shadow-lg shadow-jsyellow/20">
                          <IconComponent className="w-6 h-6" />
                        </div>
                        <h2 className="text-2xl font-bold text-jsblack leading-tight">
                          {course.title[locale]}
                        </h2>
                      </div>
 {course.tag && course.tag.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {course.tag.map((tag, index) => (
                              <span
                                key={index}
                                className="text-xs font-medium bg-jsyellow/10 text-jsyellow px-3 py-1 rounded-full"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        )}
                      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 border border-jsyellow/20">
                        <div className="flex items-center gap-3 text-gray-700 mb-4">
                          <div className="w-8 h-8 bg-jsyellow/10 rounded-full flex items-center justify-center">
                            <FaClock className="w-4 h-4 text-jsyellow" />
                          </div>
                          <div>
                            <span className="text-sm text-gray-500">
                              {locale === "az" ? "Müddət" : "Длительность"}
                            </span>
                            <p className="font-medium">
                              {course.duration} {locale === "az" ? "ay" : "месяцев"}
                            </p>
                          </div>
                        </div>

                       
                      </div>
                      
                    </div>
                  </Link>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-[280px] rounded-[32px] bg-gray-100 animate-pulse"
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CoursesSlider;
