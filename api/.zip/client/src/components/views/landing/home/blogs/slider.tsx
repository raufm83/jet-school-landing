"use client";
import { Locale } from "@/i18n/request";
import { Post, PostsResponse } from "@/types/post";
import { motion } from "framer-motion";
import { useLocale, useTranslations } from "next-intl";
import "swiper/css";
import { Autoplay } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import PostCard from "../../post/card";

interface SliderProps {
  data: PostsResponse;
}

export default function PostsSlider({ data }: SliderProps) {
  const locale = useLocale() as Locale;
  const t = useTranslations("postsPage");
  return (
    <div className="py-4">
      <Swiper
        modules={[Autoplay]}
        autoplay={{
          delay: 2000,
          disableOnInteraction: false,
        }}
        spaceBetween={24}
        breakpoints={{
          0: { slidesPerView: 1 },
          640: { slidesPerView: 2 },
          992: { slidesPerView: 3 },
        }}
        className="!pb-4"
      >
        {data.items.map((post: Post, index: number) => (
          <SwiperSlide key={index} className="rounded-3xl">
            <motion.div className="h-full shadow-lg rounded-3xl">
              <PostCard t={t} locale={locale} post={post} />
            </motion.div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}
