import Button from "@/components/ui/button";
import { getTranslations } from "next-intl/server";
import { FaCompass } from "react-icons/fa6";
import HeroConsult from "./hero-consult";
import HeroImage from "./image";

export default async function Hero() {
  const t = await getTranslations("hero");
  return (
    <div
      id="hero"
      className="container mt-10 md:mt-20 relative z-[10] flex flex-col-reverse md:flex-row items-center justify-between gap-12 md:gap-0"
    >
      {/* Left Content */}
      <div
        className="flex w-full md:max-w-[550px] flex-col gap-6 md:gap-9 text-center md:text-left"
        id="left"
      >
        <Button
          variant="secondary"
          className="shadow-jsshadow mx-auto md:mx-0"
          icon={<FaCompass size={20} color="#FCAE1E" />}
          text="#yaratmağabaşla"
        />

        <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold text-jsblack">
          {t("toJetSchool")}{" "}
          <span className="text-jsyellow">{t("welcome")}!</span>
        </h1>

        <p className="font-medium whitespace-pre-line text-[#A8A8A8] leading-7 text-base md:text-lg">
          {t("description")}
        </p>

        <HeroConsult />
      </div>

      {/* Right Content - Image Container */}
      <HeroImage />
    </div>
  );
}
