import SectionTitle from "@/components/shared/section-title";
import Button from "@/components/ui/button";
import api from "@/utils/api/axios";
import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { MdArrowRightAlt } from "react-icons/md";
import Slider from "./slider";

const fetchProjects = async () => {
  try {
    const response = await api.get("/student-projects");
    return response.data;
  } catch (error) {
    console.error("Failed to fetch projects:", error);
    return null;
  }
};

export default async function Projects() {
  try {
    const t = await getTranslations("projects");
    const projects = await fetchProjects();

    if (!projects) {
      return null;
    }

    // Projeleri yeniden eskiye sıralamak için tersine çevir
    const sortedProjects = Array.isArray(projects)
      ? projects.slice().reverse()
      : projects.items
      ? { ...projects, items: projects.items.slice().reverse() }
      : projects;

    return (
      <div id="media" className="container my-20 flex flex-col gap-8">
        <SectionTitle title={t("title")} description={t("description")} />
        <div>
          <Slider data={sortedProjects} />
        </div>
        <Link href="/projects">
          <Button
            iconPosition="right"
            className="items-center mx-auto"
            icon={<MdArrowRightAlt size={24} />}
            text={t("seeAll")}
          />
        </Link>
      </div>
    );
    
  } catch (error) {
    console.error("Projects component error:", error);
    return null;
  }
}