"use client";

import Button from "@/components/ui/button";
import { useContactModal } from "@/hooks/useContactModal";
import { useTranslations } from "next-intl";
import React from "react";
import { HiArrowSmRight } from "react-icons/hi";

export default function HeroConsult() {
  const { toggle } = useContactModal();
  const t = useTranslations("hero");
  return (
    <Button
      variant="primary"
      onClick={() => toggle()}
      className="shadow-jsshadow mx-auto md:mx-0"
      text={t("getConsult")}
      iconPosition="right"
      icon={<HiArrowSmRight size={22} />}
    />
  );
}
