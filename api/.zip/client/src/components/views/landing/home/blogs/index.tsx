import SectionTitle from "@/components/shared/section-title";
import Button from "@/components/ui/button";
import { PostType } from "@/types/enums";
import { getAllPosts } from "@/utils/api/post";
import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { MdArrowRightAlt } from "react-icons/md";
import PostsSlider from "./slider";

export default async function Blogs() {
  try {
    const t = await getTranslations("blogs");
    const projects = await getAllPosts({
      page: 1,
      limit: 5,
      type: PostType.BLOG,
      includeBlogs: true,
    });

    if (!projects) {
      return null;
    }

    return (
      <div id="media" className="container my-20 flex flex-col gap-8">
        <SectionTitle title={t("title")} description={t("description")} />
        <div>
          <PostsSlider data={projects} />
        </div>
        <Link href="/news">
          <Button
            iconPosition="right"
            className="items-center mx-auto"
            icon={<MdArrowRightAlt size={24} />}
            text={t("seeAll")}
          />
        </Link>
      </div>
    );
  } catch (error) {
    console.error("Projects component error:", error);
    return null;
  }
}
