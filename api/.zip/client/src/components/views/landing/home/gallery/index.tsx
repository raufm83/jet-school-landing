import Button from "@/components/ui/button";
import api from "@/utils/api/axios";
import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { MdArrowRightAlt } from "react-icons/md";
import GalleryClient from "../../gallery/gallery-client";
const fetchGallery = async () => {
  try {
    const response = await api.get("/gallery?limit=30");
    return response.data;
  } catch (error) {
    console.error("Failed to fetch gallery:", error);
    return null;
  }
};

export default async function Gallery() {
  try {
    const t = await getTranslations("gallery");
    const gallery = await fetchGallery();

    if (!gallery) {
      return null;
    }

    return (
      <div id="media" className="container my-20 flex flex-col gap-8">
        <GalleryClient slider initialGallery={gallery} />
        <Link href="/gallery">
          <Button
            iconPosition="right"
            className="items-center mx-auto"
            icon={<MdArrowRightAlt size={24} />}
            text={t("seeAll")}
          />
        </Link>
      </div>
    );
  } catch (error) {
    console.error("Gallery component error:", error);
    return null;
  }
}
