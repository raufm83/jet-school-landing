import ContactFormFloat from "@/components/views/landing/single-course/contact-form-float";
import CourseContent from "@/components/views/landing/single-course/course-content";
import EligibilitySection from "@/components/views/landing/single-course/course-eligibility";
import CourseHero from "@/components/views/landing/single-course/course-hero";
import TeachersSection from "@/components/views/landing/single-course/course-teachers";
import CoursesSlider from "@/components/views/landing/single-course/courses-slider";
import { Locale } from "@/i18n/request";
import { getAllCourses, getCourseDetails } from "@/utils/api/course";
import { Metadata } from "next";
import { getLocale, getTranslations } from "next-intl/server";
import { notFound } from "next/navigation";

type LocalizedString = {
  [K in Locale]: string;
};

interface ISingleCoursePageProps {
  params: {
    slug: string;
    locale: string;
  };
}

const getLocalizedMonths = (months: number): LocalizedString => {
  if (months === 1) {
    return {
      az: `${months} ay`,
      ru: `${months} месяц`,
    };
  }
  return {
    az: `${months} ay`,
    ru: `${months} месяцев`,
  };
};

export default async function SingleCoursePage({
  params,
}: ISingleCoursePageProps) {
  try {
    const [data, locale, t, courses] = await Promise.all([
      getCourseDetails(params.slug),
      getLocale() as Promise<Locale>,
      getTranslations("singleCoursePage"),
      getAllCourses({}),
    ]);

    if (!data) {
      notFound();
    }

    const duration = getLocalizedMonths(data.duration);

    return (
      <main className="min-h-screen ">
        <div className="relative container">
          <div className="flex flex-col lg:flex-row gap-8 py-20">
            <div className="w-full flex flex-col gap-8 lg:w-2/3">
              <CourseHero
                title={data.title[locale]}
                duration={duration[locale]}
                level={data.level[locale]}
                courseOverviewText={t("courseDescription")}
                tags={data.newTags[locale]}
                description={data.description[locale]}
              />

              {data.modules && data.modules.length > 0 && (
                <CourseContent
                  title={t("courseModules")}
                  locale={locale}
                  modules={data.modules}
                />
              )}

              {data.eligibility && data.eligibility.length > 0 && (
                <EligibilitySection
                  locale={locale}
                  title={t("whoIsEligibleToEnroll")}
                  eligibility={data.eligibility}
                />
              )}

              <TeachersSection
                title={t("teachers")}
                description={t("teachersDescription")}
                data={{ teachers: data.teachers }}
                locale={locale}
              />

              <CoursesSlider courses={courses} />
            </div>

            <div className="w-full lg:w-1/3 lg:sticky lg:top-5 h-fit">
              <ContactFormFloat />
            </div>
          </div>
        </div>
      </main>
    );
  } catch (error) {
    console.error("Error in SingleCoursePage:", error);
    notFound();
  }
}

export async function generateMetadata({
  params,
}: ISingleCoursePageProps): Promise<Metadata> {
  try {
    const data = await getCourseDetails(params.slug);
    const locale = params.locale as Locale;

    if (!data) {
      return {
        title: "Not Found",
        description: "The requested course was not found",
      };
    }

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "https://jetschool.az";

    const canonicalUrl =
      locale === "az"
        ? `${baseUrl}/course/${params.slug}`
        : `${baseUrl}/${locale}/course/${params.slug}`;

    const azSlug = data.slug?.az || params.slug;
    const ruSlug = data.slug?.ru || params.slug;

    return {
      title: data.title[locale],
      description: data.description[locale],
      alternates: {
        canonical: canonicalUrl,
        languages: {
          az:
            locale === "az"
              ? `${baseUrl}/course/${azSlug}`
              : `${baseUrl}/az/course/${azSlug}`,
          ru: `${baseUrl}/ru/course/${ruSlug}`,
        },
      },
      openGraph: {
        title: data.title[locale],
        description: data.description[locale],
        url: canonicalUrl,
        type: "website",
        locale: locale === "az" ? "az_AZ" : "ru_RU",
        alternateLocale: locale === "az" ? "ru_RU" : "az_AZ",
      },
      twitter: {
        card: "summary_large_image",
        title: data.title[locale],
        description: data.description[locale],
      },
      robots: {
        index: true,
        follow: true,
        googleBot: {
          index: true,
          follow: true,
          "max-snippet": -1,
          "max-image-preview": "large",
        },
      },
    };
  } catch (error) {
    console.error("Error generating metadata:", error);
    return {
      title: "Error",
      description: "Failed to load course details",
      robots: {
        index: false,
      },
    };
  }
}

export const revalidate = 60;
