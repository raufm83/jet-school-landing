import IntroSection from "@/components/views/landing/about/intro-section";
import MissionVisionSection from "@/components/views/landing/about/mission-vision-section";
import StatsSection from "@/components/views/landing/about/stats-section";
import TeamSection from "@/components/views/landing/about/team-section";
import api from "@/utils/api/axios";
import { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";

export async function generateMetadata({
  params: { locale },
}: {
  params: { locale: string };
}): Promise<Metadata> {
  const t = await getTranslations({ locale, namespace: "Metadata" });
  const aboutT = await getTranslations({ locale, namespace: "aboutPage" });

  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "https://jetschool.az";

  const canonicalUrl =
    locale === "az" ? `${baseUrl}/about-us` : `${baseUrl}/${locale}/about-us`;

  return {
    title: t("aboutPageTitle") || "Haqqımızda",
    description:
      aboutT("introduction.description1") ||
      "JET School olaraq, biz 2021-ci ildən etibarən uşaqlar və yeniyetmələr üçün texnologiya dünyasını əyləncəli və öyrədici hala gətirməyi qarşımıza məqsəd qoymuşuq.",
    alternates: {
      canonical: canonicalUrl,
      languages: {
        az: locale === "az" ? `${baseUrl}/about-us` : `${baseUrl}/az/about-us`,
        ru: `${baseUrl}/ru/about-us`,
      },
    },
    openGraph: {
      title: t("aboutPageTitle") || "Haqqımızda | JET School",
      description:
        aboutT("introduction.description1") ||
        "JET School olaraq, biz 2021-ci ildən etibarən uşaqlar və yeniyetmələr üçün texnologiya dünyasını əyləncəli və öyrədici hala gətirməyi qarşımıza məqsəd qoymuşuq.",
      url: canonicalUrl,
      type: "website",
      locale: locale === "az" ? "az_AZ" : "ru_RU",
      alternateLocale: locale === "az" ? "ru_RU" : "az_AZ",
    },
    twitter: {
      card: "summary_large_image",
      title: t("aboutPageTitle") || "Haqqımızda | JET School",
      description:
        aboutT("introduction.description1") ||
        "JET School olaraq, biz 2021-ci ildən etibarən uşaqlar və yeniyetmələr üçün texnologiya dünyasını əyləncəli və öyrədici hala gətirməyi qarşımıza məqsəd qoymuşuq.",
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-snippet": -1,
        "max-image-preview": "large",
      },
    },
  };
}

const getTeamMembers = async () => {
  try {
    return (await api.get("/team/active?limit=30")).data;
  } catch (error) {
    console.error(error);
    return [];
  }
};

export default async function AboutPage({
  params,
}: {
  params: { locale: string };
}) {
  setRequestLocale(params.locale);
  const t = await getTranslations({
    locale: params.locale,
    namespace: "aboutPage",
  });
  const teamMembers = await getTeamMembers();

  return (
    <div className="flex flex-col gap-16 py-16">
      <IntroSection
        title={t("introduction.title")}
        description1={t("introduction.description1")}
        description2={t("introduction.description2")}
      />

      <MissionVisionSection
        sectionTitle={t("mission.sectionTitle")}
        mission={{
          title: t("mission.title"),
          description: t("mission.description"),
        }}
        vision={{
          title: t("vision.title"),
          description: t("vision.description"),
        }}
      />

      <StatsSection
        stats={{
          graduatesLabel: t("stats.graduatesLabel"),
          groupsLabel: t("stats.groupsLabel"),
          studentsLabel: t("stats.studentsLabel"),
        }}
      />

      <TeamSection
        teamMembers={teamMembers}
        title={t("team.title")}
        description={t("team.description")}
      />
    </div>
  );
}
