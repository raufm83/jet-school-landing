"use client";
import CourseForm from "@/components/views/dashboard/courses/course-form";
import { CourseFormInputs } from "@/types/course";
import api from "@/utils/api/axios";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

export default function CreateCoursePage() {
  const router = useRouter();
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<CourseFormInputs>({
    defaultValues: {
      title: { az: "", ru: "" },
      description: { az: "", ru: "" },
      slug: { az: "", ru: "" },
      level: { az: "Başlanğıc", ru: "Начинающий" },
      duration: 0,
      published: false,
    },
  });

  const onSubmit = async (data: CourseFormInputs) => {
    try {
      const response = await api.post("/courses", data);

      if (response.status === 201) {
        toast.success("Kurs uğurla yaradıldı");
        router.push("/dashboard/courses");
        router.refresh();
      }
    } catch (error: any) {
      console.error("Yaratma xətası:", error);
      toast.error(
        error.response?.data?.message || "Xəta baş verdi. Yenidən cəhd edin"
      );
    }
  };

  return (
    <CourseForm
      mode="create"
      onSubmit={onSubmit}
      register={register}
      errors={errors}
      isSubmitting={isSubmitting}
      handleSubmit={handleSubmit}
      router={router}
      watch={watch}
      setValue={setValue}
    />
  );
}
