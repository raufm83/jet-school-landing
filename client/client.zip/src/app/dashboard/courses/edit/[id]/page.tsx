"use client";
import CourseForm from "@/components/views/dashboard/courses/course-form";
import { CourseFormInputs } from "@/types/course";
import api from "@/utils/api/axios";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

export default function EditCoursePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [originalData, setOriginalData] = useState<CourseFormInputs | null>(
    null
  );

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<CourseFormInputs>();

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const { data } = await api.get(`/courses/${params.id}`);
        const dataWithoutId = {
          ...data,
          id: undefined,
          modules: undefined,
          teachers: undefined,
          eligibility: undefined,
        };
        setOriginalData(data);
        reset(dataWithoutId);
      } catch (error) {
        console.error("Kurs məlumatlarını yükləmə xətası:", error);
        toast.error("Kurs məlumatları yüklənə bilmədi");
        router.push("/dashboard/courses");
      } finally {
        setIsLoading(false);
      }
    };

    fetchCourse();
  }, [params.id, reset, router]);

  const onSubmit = async (data: CourseFormInputs) => {
    try {
      const response = await api.patch(`/courses/${params.id}`, {
        ...data,
        duration: Number(data.duration),
      });

      if (response.status === 200) {
        toast.success("Kurs uğurla yeniləndi");
        router.push("/dashboard/courses");
        router.refresh();
      }
    } catch (error: any) {
      console.error("Yeniləmə xətası:", error);
      toast.error(
        error.response?.data?.message || "Xəta baş verdi. Yenidən cəhd edin"
      );
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 min-h-screen w-full flex items-center justify-center">
        <p>Yüklənir...</p>
      </div>
    );
  }

  return (
    <CourseForm
      mode="edit"
      onSubmit={onSubmit}
      register={register}
      errors={errors}
      isSubmitting={isSubmitting}
      handleSubmit={handleSubmit}
      initialValues={originalData}
      router={router}
      watch={watch}
      setValue={setValue}
    />
  );
}
