import type { Viewport } from "next";
import { Manrope } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";
import { GoogleAnalytics } from "@next/third-parties/google";

export const viewport: Viewport = {
  themeColor: "#ffffff",
};

const manrope = Manrope({
  display: "swap",
  preload: true,
  subsets: ["latin", "latin-ext", "cyrillic-ext"],
  weight: ["200", "300", "400", "600", "700"],
});

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${manrope.className} scroll-smooth antialiased overflow-x-hidden`}
      >
        <h1 className="hidden">JET School</h1>
        {children}
        <Toaster />
        <GoogleAnalytics gaId="G-8PKPCDFDSF" />
      </body>
    </html>
  );
}
