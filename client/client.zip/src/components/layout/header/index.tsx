"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { motion, AnimatePresence } from "framer-motion";
import { HiOutlinePhone } from "react-icons/hi2";
import { HiMenuAlt3, HiX } from "react-icons/hi";

import Logo from "./logo";
import NavLink from "./nav-link";
import Button from "@/components/ui/button";
import LanguageSwitcher from "@/components/shared/language-switcher";
import { useContactModal } from "@/hooks/useContactModal";
import { getNavLinks } from "@/data/navlinks";
import { usePathname } from "@/i18n/routing";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { toggle } = useContactModal();
  const t = useTranslations("navbar");
  const navLinks = getNavLinks(t);
  const path = usePathname();

  useEffect(() => {
    document.body.style.overflowY = isMenuOpen ? "hidden" : "auto";
    return () => {
      document.body.style.overflowY = "auto";
    };
  }, [isMenuOpen]);

  return (
    <header
      className="
        transition-all relative z-[999]
        pt-6 sm:pt-8 md:pt-10 lg:pt-12 xl:pt-14 2xl:pt-16 4xl:pt-20
        duration-300
      "
    >
      <nav
        className="
        container  flex justify-between items-center
        "
      >
        <Link href="/" className="relative z-50 p-0 mb-[3px]">
          <Logo className="w-24  md:w-28 lg:w-32 xl:w-36 2xl:w-40 4xl:w-48 
[@media(min-width:3500px)]:!w-[300px]
[@media(min-width:3500px)]:!h-[80px]
          
          " />
        </Link>

        <div className="hidden lg:flex items-center gap-6 xl:gap-8 2xl:gap-10 4xl:gap-12">
          <menu className="flex flex-nowrap whitespace-nowrap gap-4 md:gap-6 lg:gap-8 items-center">
            {navLinks.map((link) => (
              <NavLink
                key={link.title}
                isActive={path === link.href}
                {...link}
                handleClick={() => setIsMenuOpen(false)}
                className="py-1 md:py-2 whitespace-nowrap text-base md:text-md lg:text-md [@media(min-width:3500px)]:!text-2xl"
              />
            ))}
          </menu>

          <div className="flex items-center gap-3 md:gap-4">
            <LanguageSwitcher />
            <Button
              onClick={() => {
                setIsMenuOpen(false);
                toggle();
              }}
              icon={<HiOutlinePhone size={20} />}
              className="font-medium text-sm [@media(min-width:3500px)]:!text-2xl md:text-base h-10 md:h-12 px-4 md:px-6 bg-jsyellow hover:bg-[#00A300] text-white hover:text-white"
              text={t("contactus")}
            />
          </div>
        </div>

        <div className="flex items-center gap-2 lg:hidden relative z-50">
          <LanguageSwitcher />
          <button
            onClick={() => setIsMenuOpen((o) => !o)}
            className="p-2 md:p-3 text-jsblack hover:bg-gray-100 rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <HiX size={24} /> : <HiMenuAlt3 size={24} />}
          </button>
        </div>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-white m-20 z-40 lg:hidden pt-20 md:pt-24"
            >
              <div className="container px-4 py-6">
                <div className="flex flex-col gap-3 md:gap-4">
                  {navLinks.map((link) => (
                    <NavLink
                      key={link.title}
                      {...link}
                      handleClick={() => setIsMenuOpen(false)}
                      className="text-lg md:text-xl py-3 border-b border-gray-100 cursor-pointer whitespace-nowrap"
                    />
                  ))}
                </div>
                <div className="mt-8 flex flex-col gap-4">
                  <Button
                    onClick={() => {
                      setIsMenuOpen(false);
                      toggle();
                    }}
                    icon={<HiOutlinePhone size={22} />}
                    className="font-medium w-full text-base md:text-lg h-12 bg-jsyellow text-white"
                    text={t("contactus")}
                  />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
}
