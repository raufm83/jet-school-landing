// src/components/shared/footer.tsx
import { ContactData } from "@/types/contact";
import { getContact } from "@/utils/api/contact";
import { getLocale, getTranslations } from "next-intl/server";
import Image from "next/image";
import Link from "next/link";
import {
  FaClock,
  FaEnvelope,
  FaFacebook,
  FaInstagram,
  FaMapMarkerAlt,
  FaPhone,
  FaWhatsapp,
  FaYoutube,
} from "react-icons/fa";
import { FaTiktok } from "react-icons/fa6";
import api from "@/utils/api/axios";

interface Course {
  id: string;
  title: { az: string; ru: string };
  slug: { az: string; ru: string };
  createdAt: string;
}
interface CoursesResponse {
  items?: Course[];
}

const fetchCourses = async (): Promise<CoursesResponse | Course[] | null> => {
  try {
    const { data } = await api.get("/courses");
    return data;
  } catch {
    console.error("Failed to fetch courses");
    return null;
  }
};

export default async function Footer() {
  try {
    const t = await getTranslations("footer");
    const localeRaw = await getLocale();
    const lang = (localeRaw === "ru" ? "ru" : "az") as "az" | "ru";
    const contact: ContactData = await getContact();
    const coursesData = await fetchCourses();
    const currentYear = new Date().getFullYear();

    const sortedCourses: Course[] = Array.isArray(coursesData)
      ? coursesData.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      : coursesData?.items
      ? coursesData.items.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      : [];

    return (
      <footer id="contacts" className="bg-jsyellow w-full text-white  mt-16 md:mt-20">
        <div className="absolute inset-y-0 right-0 z-0 mix-blend-soft-light opacity-50 blur-[2px]">
          <div className="absolute top-[10%] right-0 md:-left-[5%]">
            <Image src="/hero/rocket.png" alt="" width={300} height={300} className="w-[200px] md:w-[300px] " />
          </div>
          <div className="absolute top-1/2 right-0 md:-right-[5%]">
            <Image src="/hero/book.png" alt="" width={300} height={300} className="w-[200px] md:w-[300px]" />
          </div>
          <div className="hidden md:block absolute bottom-4 left-[20%] opacity-70 blur-[2px]">
            <Image src="/hero/laptop.png" alt="" width={300} height={300} className="w-[200px] md:w-[300px]" />
          </div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 md:px-8 lg:px-12 xl:px-16 2xl:px-20 3xl:px-24 4xl:px-32 relative z-10 py-8 md:py-12 lg:py-16">
          <div className="grid grid-cols-1  md:grid-cols-[2fr_3fr] gap-6 md:gap-8 lg:gap-12">
            <div className="flex flex-col gap-6">
              <h2 className="text-2xl md:text-3xl [@media(min-width:3500px)]:!text-5xl font-bold">JET School</h2>
              <p className="max-w-xs [@media(min-width:3500px)]:!text-3xl md:max-w-sm text-white/80 text-sm md:text-base">
                {t("tagline")}
              </p>

              <div className="flex flex-col gap-5">
                <Link
                  href={`https://maps.google.com?q=${encodeURIComponent(contact.address[lang])}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 [@media(min-width:3500px)]:!text-3xl text-sm md:text-base hover:underline"
                >
                  <FaMapMarkerAlt className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  {contact.address[lang]}
                </Link>
                <Link
                  href={`https://maps.google.com?q=${encodeURIComponent(contact.address2[lang])}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 [@media(min-width:3500px)]:!text-3xl text-sm md:text-base hover:underline"
                >
                  <FaMapMarkerAlt className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  {contact.address2[lang]}
                </Link>

                <div className="flex flex-col gap-3">
                  <Link
                    href={`tel:${contact.phone.replace(/\D/g, "")}`}
                    className="flex items-center gap-3 text-sm [@media(min-width:3500px)]:!text-3xl md:text-base hover:underline"
                  >
                    <FaPhone className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" /> {contact.phone}
                  </Link>
                  <Link
                    href={`https://wa.me/${contact.whatsapp.replace(/\D/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-sm [@media(min-width:3500px)]:!text-3xl md:text-base hover:underline"
                  >
                    <FaWhatsapp className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" /> {contact.whatsapp}
                  </Link>
                  <Link
                    href={`mailto:${contact.email}`}
                    className="flex items-center gap-3 text-sm [@media(min-width:3500px)]:!text-3xl md:text-base hover:underline"
                  >
                    <FaEnvelope className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" /> {contact.email}
                  </Link>
                </div>

                <div className="flex items-start gap-3 text-sm md:text-base">
                  <FaClock className="w-5 h-5 mt-1 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  <div className="flex flex-col">
                    <span className="[@media(min-width:3500px)]:!text-2xl">{contact.workingHours[lang].weekdays}</span>
                    <span className="[@media(min-width:3500px)]:!text-2xl">{contact.workingHours[lang].sunday}</span>
                  </div>
                </div>

                <div className="flex gap-4 pt-2">
                  <Link
                    href="https://facebook.com/jetschool.az"
                    target="_blank"
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition"
                  >
                    <FaFacebook className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  </Link>
                  <Link
                    href="https://instagram.com/jet.school.baku"
                    target="_blank"
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition"
                  >
                    <FaInstagram className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  </Link>
                  <Link
                    href="https://youtube.com/@jetschoolbaku"
                    target="_blank"
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition"
                  >
                    <FaYoutube className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  </Link>
                  <Link
                    href="https://tiktok.com/@jetschoolbaku"
                    target="_blank"
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition"
                  >
                    <FaTiktok className="w-5 h-5 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10" />
                  </Link>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-8 md:gap-10">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                <div>
                  <h3 className="text-xl font-bold [@media(min-width:3500px)]:!text-5xl">{t("explore")}</h3>
                  <ul className="flex flex-col gap-4 mt-2">
                    <li><Link href="/" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("home")}</Link></li>
                    <li><Link href="/about-us" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("about")}</Link></li>
                    <li><Link href="/gallery" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("gallery")}</Link></li>
                    <li><Link href="/blog" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("blog")}</Link></li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-xl font-bold [@media(min-width:3500px)]:!text-5xl">{t("courses")}</h3>
                  <ul className="flex flex-col gap-2 [@media(min-width:3500px)]:!gap-5 [@media(min-width:3500px)]:!mt-4">
                    {sortedCourses.length > 0 ? (
                      sortedCourses.map((c) => (
                        <li key={c.id} className="[@media(min-width:3500px)]:!text-3xl">
                          <Link href={`/course/${c.slug[lang]}`} className="hover:underline">
                            {c.title[lang]}
                          </Link>
                        </li>
                      ))
                    ) : (
                      <li className="text-sm">{t("noCourses")}</li>
                    )}
                  </ul>
                </div>
                <div>
                  <h3 className="text-xl font-bold [@media(min-width:3500px)]:!text-5xl">{t("resources")}</h3>
                  <ul className="flex flex-col gap-2 [@media(min-width:3500px)]:!gap-5 [@media(min-width:3500px)]:!mt-4">
                    <li><Link href="/glossary" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("glossary")}</Link></li>
                    <li><Link href="/news" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("news")}</Link></li>
                    <li><Link href="/projects" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("projects")}</Link></li>
                    <li><Link href="/contact-us" className="hover:underline [@media(min-width:3500px)]:!text-3xl">{t("contact")}</Link></li>
                  </ul>
                </div>
              </div>

              
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/20 text-center  [@media(min-width:3500px)]:!text-3xl text-sm md:text-base">
            © {currentYear} JET School. {t("copyright")}
          </div>
        </div>
      </footer>
    );
  } catch (err) {
    console.error("Footer error:", err);
    return (
      <footer className="bg-jsyellow w-full text-white py-6 text-center">
        <p>© {new Date().getFullYear()} JET School</p>
      </footer>
    );
  }
}
