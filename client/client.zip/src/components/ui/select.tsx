import React, { useEffect, useRef, useState } from "react";
import { FieldError, UseFormRegisterReturn } from "react-hook-form";
import { motion, AnimatePresence } from "framer-motion";
import { MdKeyboardArrowDown } from "react-icons/md";
import { useOnClickOutside } from "@/hooks/useClickOutside";

interface Option {
  value: string | number;
  label: string;
}

interface SelectProps {
  options: Option[];
  label?: string;
  description?: string;
  error?: FieldError | string;
  value?: string | number;
  registration?: Partial<UseFormRegisterReturn>;
  onChange?: (value: string | number) => void;
  placeholder?: string;
  className?: string;
}

const Select = React.forwardRef<HTMLDivElement, SelectProps>(
  (
    {
      options,
      label,
      description,
      error,
      value,
      onChange,
      placeholder = "Select an option",
      className = "",
      registration,
    },
    ref
  ) => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedOption, setSelectedOption] = useState<Option | null>(
      options.find((opt) => opt.value === value) || null
    );
    const [highlightedIndex, setHighlightedIndex] = useState<number>(-1);
    const selectRef = useRef<HTMLDivElement>(null);
    const optionsRef = useRef<HTMLDivElement>(null);

    useOnClickOutside(selectRef, () => setIsOpen(false));

    const errorMessage = error
      ? typeof error === "string"
        ? error
        : error.message
      : undefined;

    useEffect(() => {
      if (value) {
        const option = options.find((opt) => opt.value === value);
        if (option) setSelectedOption(option);
      }
    }, [value, options]);

    const handleSelect = (option: Option) => {
      setSelectedOption(option);
      setIsOpen(false);
      if (onChange) onChange(option.value);
      if (registration?.onChange) {
        const event = {
          target: { value: option.value, name: registration.name },
        } as unknown as React.ChangeEvent<HTMLInputElement>;
        registration.onChange(event);
      }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (
        !isOpen &&
        (e.key === "Enter" || e.key === " " || e.key === "ArrowDown")
      ) {
        e.preventDefault();
        setIsOpen(true);
        setHighlightedIndex(0);
        return;
      }

      if (!isOpen) return;

      switch (e.key) {
        case "Escape":
          setIsOpen(false);
          break;
        case "ArrowUp":
          e.preventDefault();
          setHighlightedIndex((prev) =>
            prev <= 0 ? options.length - 1 : prev - 1
          );
          break;
        case "ArrowDown":
          e.preventDefault();
          setHighlightedIndex((prev) =>
            prev >= options.length - 1 ? 0 : prev + 1
          );
          break;
        case "Enter":
        case " ":
          e.preventDefault();
          if (highlightedIndex >= 0) {
            handleSelect(options[highlightedIndex]);
          }
          break;
      }
    };

    return (
      <motion.div
        className="flex flex-col gap-2 w-full"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        ref={ref}
      >
        {label && (
          <label className="font-semibold [@media(min-width:3500px)]:!text-3xl  text-xl text-jsblack mb-1">
            {label}
          </label>
        )}

        {description && (
          <span className="text-gray-600 [@media(min-width:3500px)]:!text-3xl text-sm">{description}</span>
        )}

        <div className="relative" ref={selectRef}>
          <motion.div
            tabIndex={0}
            role="button"
            aria-haspopup="listbox"
            aria-expanded={isOpen}
            aria-labelledby={label}
            className={`
              w-full
              px-6
              py-4
              bg-[#fef7eb]
              border
              border-jsyellow
              rounded-[32px]
              text-jsblack
              font-semibold
              outline-none
              cursor-pointer
              flex
              justify-between
              items-center
              transition-all
              duration-300
              ease-in-out
              hover:shadow-md
              ${errorMessage ? "border-red-500 bg-red-50" : ""}
              ${className}
            `}
            onClick={() => setIsOpen(!isOpen)}
            onKeyDown={handleKeyDown}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
          >
            <span className={!selectedOption ? "text-gray-400 [@media(min-width:3500px)]:!text-3xl" : ""}>
              {selectedOption ? selectedOption.label : placeholder}
            </span>
            <motion.div
              animate={{ rotate: isOpen ? 180 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <MdKeyboardArrowDown className="w-6 h-6 [@media(min-width:3500px)]:!w-10 [@media(min-width:3500px)]:!h-10 text-jsyellow" />
            </motion.div>
          </motion.div>

          <AnimatePresence>
            {isOpen && (
              <motion.div
                ref={optionsRef}
                role="listbox"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="absolute z-50 w-full mt-2 bg-white border border-jsyellow rounded-[24px] overflow-hidden shadow-lg"
              >
                {options.map((option, index) => (
                  <motion.div
                    key={option.value}
                    role="option"
                    aria-selected={selectedOption?.value === option.value}
                    className={`
                      px-6 
                      py-3 
                      cursor-pointer 
                      transition-colors
                      [@media(min-width:3500px)]:!text-3xl
                      ${
                        highlightedIndex === index
                          ? "bg-[#fef7eb]"
                          : "hover:bg-[#fef7eb]"
                      }
                      ${
                        selectedOption?.value === option.value
                          ? "bg-jsyellow/10"
                          : ""
                      }
                    `}
                    onClick={() => handleSelect(option)}
                    whileHover={{ backgroundColor: "#fef7eb" }}
                  >
                    {option.label}
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {errorMessage && (
          <span className="text-sm text-red-500 pl-2">{errorMessage}</span>
        )}
      </motion.div>
    );
  }
);

Select.displayName = "Select";

export default Select;
