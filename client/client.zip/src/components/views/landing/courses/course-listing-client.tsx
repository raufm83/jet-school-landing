"use client";

import { useState, useEffect } from "react";
import { Locale } from "@/i18n/request";
import { CourseResponse } from "@/types/course";
import CourseCard from "./course-card";

interface TranslationProps {
  filters: string;
  level: string;
  duration: string;
  tags: string;
  resetFilters: string;
  noCoursesFound: string;
  changeCriteria: string;
}

interface CourseListingClientProps {
  courses: CourseResponse;
  locale: Locale;
  translations: TranslationProps;
}


interface ActiveFilters {
  levels: string[];
  durations: number[];
  tags: string[];
}

export default function CourseListingClient({
  courses,
  locale,
  translations,
}: CourseListingClientProps) {
  const [filteredCourses, setFilteredCourses] = useState(courses.items || []);



  const [activeFilters] = useState<ActiveFilters>({
    levels: [],
    durations: [],
    tags: [],
  });

  useEffect(() => {
    let filtered = courses.items || [];


    if (activeFilters.levels.length > 0) {
      filtered = filtered.filter((course) =>
        activeFilters.levels.includes(course.level[locale])
      );
    }

    if (activeFilters.durations.length > 0) {
      filtered = filtered.filter((course) =>
        activeFilters.durations.includes(course.duration)
      );
    }

    if (activeFilters.tags.length > 0) {
      filtered = filtered.filter(
        (course) =>
          course.tag &&
          course.tag.some((tag) => activeFilters.tags.includes(tag))
      );
    }

    setFilteredCourses(filtered);
  }, [ activeFilters, courses.items, locale]);

  return (
    <>
      <div className="mb-10">
        <div className="flex flex-col md:flex-row gap-4 mb-6">

          
        </div>
      </div>

      <div className="flex flex-col justify-center md:flex-row gap-8">
        {/* Filter sidebar - hidden on mobile, shown by button */}
      

        {/* Course grid */}
        <div className="md:w-2/1">
          {filteredCourses.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium text-gray-600">
                {translations.noCoursesFound}
              </h3>
              <p className="mt-2 text-gray-500">
                {translations.changeCriteria}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} locale={locale} />
                
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
