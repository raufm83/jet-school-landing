"use client";
import { usePathname } from "next/navigation";
import { useTranslations } from "next-intl";
import Link from "next/link";
import { useBreadcrumbTitle } from "@/hooks/BreadcrumbTitleContext";
import { useEffect, useState } from "react";

interface BreadcrumbsProps {
  dynamicTitle?: string;
}

export default function Breadcrumbs({
  dynamicTitle: propDynamicTitle,
}: BreadcrumbsProps) {
  // HOOK-lar HƏMİŞƏ COMPONENT-in ƏN BAŞINDA!
  const { dynamicTitle: contextDynamicTitle } = useBreadcrumbTitle();
  const finalDynamicTitle = propDynamicTitle ?? contextDynamicTitle ?? null;

  const pathname = usePathname();
  const t = useTranslations();

  const [singleTitle, setSingleTitle] = useState<string | null>(null);

  // (useState, useEffect YUXARIDA QALIR!)
  const segments = pathname.split("/").filter(Boolean);
  const locale = segments[0];
  const isMultilang = ["az", "ru"].includes(locale);

  const filteredSegments = isMultilang ? segments.slice(1) : segments;
  const isSinglePage = filteredSegments.length === 2;
  const lastIndex = filteredSegments.length - 1;

  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "https://jetschool.az";

  useEffect(() => {
    if (isSinglePage && !finalDynamicTitle && filteredSegments[lastIndex]) {
      const slug = filteredSegments[lastIndex];
      fetch(`${baseUrl}/api/courses/${slug}`)
        .then((res) => res.json())
        .then((data) => {
          setSingleTitle(data?.title?.[locale] ?? null);
        })
        .catch(() => setSingleTitle(null));
    }
  }, [isSinglePage, finalDynamicTitle, filteredSegments, lastIndex, locale]);

  // **EARLY RETURN-lar indi hook-lardan sonra gəlir**
  if (segments.length === 0) return null;
  if (segments.length === 1 && isMultilang) return null;

  return (
    <nav className="p-2 text-sm text-gray-700 flex gap-1 items-center">
      <Link
        href={isMultilang ? `/${locale}` : "/"}
        className="transition-colors"
      >
        {t("home")}
      </Link>
      {filteredSegments.map((segment, index) => {
        if (!segment) return null;

        const href =
          "/" + segments.slice(0, index + (isMultilang ? 2 : 1)).join("/");

        let label: string;

        // Single page ve son segment ise, dynamicTitle veya backend'den gelen başlık göster
        if (
          isSinglePage &&
          index === lastIndex &&
          (finalDynamicTitle || singleTitle)
        ) {
          label = finalDynamicTitle ?? singleTitle ?? "";
        }
        // Son segment ise, prettify et
        else if (index === lastIndex) {
          label = decodeURIComponent(segment)
            .replace(/-/g, " ")
            .replace(/\b\w/g, (c) => c.toUpperCase());
        }
        // Ara segmentlerde önce çeviri, yoksa prettify
        else {
          const labelKey = segment.toLowerCase();
          const translation = t(`breadcrumbs.${labelKey}`, { default: "" });
          label = translation
            ? translation
            : decodeURIComponent(labelKey)
                .replace(/-/g, " ")
                .replace(/\b\w/g, (c) => c.toUpperCase());
        }

        return (
          <span key={href} className="flex items-center gap-1">
            <span>&gt;</span>
            {index === lastIndex ? (
              <span className="font-semibold">{label}</span>
            ) : (
              <Link href={href} className="transition-colors">
                {label}
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
