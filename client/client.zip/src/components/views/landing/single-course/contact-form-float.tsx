"use client";
import { motion } from "framer-motion";
import { useTranslations } from "next-intl";
import ContactFormForSingle from "../contact-us/contact-form-for-single";

export default function ContactFormFloat() {
  const t = useTranslations("singleCoursePage");
  return (
    <motion.div
      className="bg-white border mt-12 mb-6 border-jsyellow rounded-[32px] p-8"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="text-2xl [@media(min-width:3500px)]:!text-5xl font-semibold text-jsblack mb-6">
        {t("enroll")}
      </h3>
      <ContactFormForSingle />
    </motion.div>
  );
}
