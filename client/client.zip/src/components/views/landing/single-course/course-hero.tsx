import React from "react";
import CourseContent from "./course-content";
import { Locale } from "@/i18n/request";
import {getTranslations } from "next-intl/server";
interface CourseHeroProps {
  title: string;
  description: string;
  courseOverviewText: string;
  tags?: string[];
  locale: Locale;
  data:any;
  params: {
    slug: string;
    locale: string;
  };
}

export default async function CourseHero({
  title,
  description,
  courseOverviewText,
  tags = [],
  locale,
  data
}: CourseHeroProps) {
 
  const t = await getTranslations("singleCoursePage");
  return (
    <div className="
      w-full
      
      flex flex-col gap-4 sm:gap-5 lg:gap-6
      animate-fadeIn
      mx-auto
      [@media(min-width:3500px)]:!text-5xl
    ">
   

      <h1 className="
        text-xl
        sm:text-2xl
        md:text-3xl
        lg:text-3xl
        font-bold
        leading-snug
        text-jsblack
      [@media(min-width:3500px)]:!text-5xl
        
      ">
        {title}
      </h1>

      {tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, index) => (
            <span
              key={index}
              className="
                bg-gray-100 text-gray-700 px-3 py-1 rounded-full
                text-xs sm:text-sm
      [@media(min-width:3500px)]:!text-2xl

              "
            >
              {tag}
            </span>
          ))}
        </div>
      )}

    <div className="flex gap-6 flex-col
      [@media(min-width:3500px)]:!text-5xl
    lg:flex-row w-full 
    pb-10
    ">
        <div className="
        bg-[#fef7eb]
        border border-jsyellow
        rounded-xl sm:rounded-2xl lg:rounded-[32px]
        p-3 sm:p-4 lg:p-6
        pb-10
        transition-all duration-300
        hover:scale-[1.01] hover:shadow-lg
        w-full lg:w-[50%]
      [@media(min-width:3500px)]:!text-2xl
      xl:text-2xl
      

      ">

        <p className="font-semibold text-base sm:text-lg lg:text-xl mb-2 sm:mb-3 lg:mb-4 
      xl:text-2xl
      [@media(min-width:3500px)]:!text-3xl
      
      ">
          {courseOverviewText}
        </p>
        <div
          dangerouslySetInnerHTML={{ __html: description }}
          className="text-gray-600 prose prose-xs sm:prose-sm lg:prose-base max-w-none
      [@media(min-width:3500px)]:!text-3xl
          
          "
        ></div>
      </div>
                    <div className="w-full lg:w-[50%] flex ">
                      <CourseContent
                        title={t("courseModules")}
                        locale={locale}
                        modules={data.modules}
                      />
                    </div>
    </div>
                
    </div>
  );
} 