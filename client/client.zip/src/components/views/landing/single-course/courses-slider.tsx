"use client";

import SectionTitle from "@/components/shared/section-title";
import { Locale } from "@/i18n/request";
import { Course, CourseResponse } from "@/types/course";
import { getIcon } from "@/utils/icon";
import { useTranslations } from "next-intl";
import Link from "next/link";
import { useEffect, useState } from "react";
import { FaClock, FaGraduationCap } from "react-icons/fa";
import "swiper/css";
import { Autoplay } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";

interface ICoursesSlider {
  courses: CourseResponse;
  locale?: Locale;
}

const CoursesSlider = ({ courses, locale = "az" }: ICoursesSlider) => {
  const t = useTranslations("courseInfoCP");
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const displayCourses = courses.items;
  if (!displayCourses) {
    return null;
  }

  return (
    <div className="flex flex-col gap-8">
      <SectionTitle title={t("title")} />

      <div className="relative">
        {isClient ? (
          <Swiper
            modules={[Autoplay]}
            spaceBetween={24}
            breakpoints={{
              320: {
                slidesPerView: 1,
              },
              640:{
                slidesPerView:2,
              },
              900:{
                slidesPerView:3,
              },
              1400:{
                slidesPerView:4
              }
            }}
            autoplay={{
              delay: 2000,
              disableOnInteraction: false,
            }}
            className="swiper-courses py-8"
          >
            {displayCourses.map((course: Course) => {
              const IconComponent = getIcon(course.icon);

              return (
                <SwiperSlide key={course.id} className="h-full">
  <Link
    href={`/${locale}/course/${course.slug[locale]}`}
    className="relative flex flex-col h-[380px]  w-full bg-[#fef7eb] border-2 border-jsyellow rounded-[32px] overflow-hidden"
  >
                    <div className="absolute  top-0 left-0 right-0 h-24 bg-gradient-to-b from-jsyellow/10 to-transparent" />

                    <div className="relative p-8 flex flex-col justify-between gap-6 h-full">
                      <div className="flex justify-end">
                        <div className="flex items-center gap-2 bg-white border border-jsyellow/20 px-4 py-2 rounded-full">
                          <FaGraduationCap className="w-4 h-4 text-jsyellow" />
                          <span className="text-sm font-medium [@media(min-width:3500px)]:!text-2xl text-jsblack">
                            {course.level[locale]}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-start gap-4 ">
                        <div className="flex-shrink-0 w-12 h-12 [@media(min-width:3500px)]:!w-[80px] [@media(min-width:3500px)]:!h-[80px] bg-jsyellow text-white rounded-2xl flex items-center justify-center shadow-lg shadow-jsyellow/20">
                          <IconComponent className="w-6 h-6 [@media(min-width:3500px)]:!w-12 [@media(min-width:3500px)]:!h-12 " />
                        </div>
                        <h2 className="text-2xl [@media(min-width:3500px)]:!text-3xl font-bold text-jsblack leading-tight">
                          {course.title[locale]}
                        </h2>
                      </div>

                      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 border border-jsyellow/20">
                        <div className="flex items-center  gap-3 text-gray-700">
                          <div className="w-8 h-8 bg-jsyellow/10 rounded-full flex items-center justify-center">
                            <FaClock className="w-4 h-4 text-jsyellow [@media(min-width:3500px)]:!w-8 [@media(min-width:3500px)]:!h-8" />
                          </div>
                          <div>
                            <span className="text-sm [@media(min-width:3500px)]:!text-2xl text-gray-500">
                              {locale === "az" ? "Müddət" : "Длительность"}
                            </span>
                            <p className="font-medium [@media(min-width:3500px)]:!text-2xl">
                              {course.duration}{" "}
                              {locale === "az" ? "ay" : "месяцев"}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </SwiperSlide>
              );
            })}
          </Swiper>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-[280px] rounded-[32px] bg-gray-100 animate-pulse"
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CoursesSlider;
