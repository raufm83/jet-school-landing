import { getTranslations } from "next-intl/server";
import Link from "next/link";

interface GlossaryTermDetailProps {
  term: string;
  definition: string;
  categoryName?: string;
  categorySlug?: string;
  tags: string[];
  relatedTerms?: {
    id: string;
    term: {
      az: string;
      ru: string;
    };
    slug: {
      az: string;
      ru: string;
    };
  }[];
  tagsText: string;
  categoryText: string;
  relatedTermsText: string;
  language: string; // 'az' or 'ru'
}

export default async function GlossaryTermDetail({
  term,
  definition,
  categoryName,
  categorySlug,
  tags,
  relatedTerms,
  tagsText,
  categoryText,
  relatedTermsText,
  language,
}: GlossaryTermDetailProps) {
  const t = await getTranslations("glossary");
  const getTitleText = (locale: string) => {
    switch (locale) {
      case "az":
        return `${term} ${t("whats")}`;
      case "ru":
        return `${t("whats")} ${term}?`;
      default:
        break;
    }
  };
  return (
    <div className="flex flex-col gap-6 animate-fadeIn">
      <div className="flex flex-wrap items-center gap-4">
        {categoryName && categorySlug && (
          <Link href={`/glossary/category/${categorySlug}`}>
            <span className="bg-jsyellow/10 text-jsblack px-4 py-2 rounded-full cursor-pointer">
              {`${categoryText}: ${categoryName}`}
            </span>
          </Link>
        )}
      </div>

      <h1 className="text-5xl font-bold leading-[1.3] text-jsblack">
        {getTitleText(language)}
      </h1>

      <div
        dangerouslySetInnerHTML={{ __html: definition }}
        className="text-gray-600 prose max-w-none prose-headings:text-jsblack prose-li:list-disc prose-li:ml-4"
      ></div>

      {tags && tags.length > 0 && (
        <div className="mt-4">
          <h3 className="font-semibold mb-2">{tagsText}:</h3>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <Link key={index} href={`/glossary/search?q=${tag}`}>
                <span className="bg-jsyellow/10 text-jsblack px-3 py-1 rounded-full text-sm cursor-pointer">
                  {tag}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {relatedTerms && relatedTerms.length > 0 && (
        <div className="mt-6">
          <h3 className="font-semibold mb-2">{relatedTermsText}:</h3>
          <div className="flex flex-wrap gap-2">
            {relatedTerms.map((relatedTerm) => (
              <Link
                key={relatedTerm.id}
                href={`/glossary/term/${
                  relatedTerm.slug[language as keyof typeof relatedTerm.slug]
                }`}
              >
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm cursor-pointer">
                  {relatedTerm.term[language as keyof typeof relatedTerm.term]}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
