import Link from "next/link";

interface GlossaryTerm {
  id: string;
  term: {
    az: string;
    ru: string;
  };
  slug: {
    az: string;
    ru: string;
  };
  categoryId?: string;
  category?: {
    name: {
      az: string;
      ru: string;
    };
  };
}

interface GlossaryTermListProps {
  terms: GlossaryTerm[];
  categoryName?: string;
  title: string;
  categoryText: string;
  language: string; // 'az' or 'ru'
  emptyText: string;
}

export default function GlossaryTermList({
  terms,
  categoryName,
  title,
  categoryText,
  language,
  emptyText,
}: GlossaryTermListProps) {
  return (
    <div className="flex flex-col gap-6 animate-fadeIn">
      <h1 className="text-4xl font-bold leading-[1.3] text-jsblack">{title}</h1>

      {categoryName && (
        <div className="flex items-center gap-4 mb-4">
          <span className="bg-jsyellow/10 text-jsblack px-4 py-2 rounded-full">
            {`${categoryText}: ${categoryName}`} 
          </span>
        </div>
      )}

      {terms.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {terms.map((term) => (
            <Link
              key={term.id}
              href={`/glossary/term/${
                term.slug[language as keyof typeof term.slug]
              }`}
            >
              <div
                className="border rounded-[16px] p-6 hover:shadow-md transition-shadow duration-300 cursor-pointer bg-[#fef9e7]
border-jsblack/20"
              >
                <h3 className="text-2xl font-semibold text-jsblack mb-2">
                  {term.term[language as keyof typeof term.term]} 
                </h3>

                {term.category && (
                  <span className="bg-jsyellow/10 text-jsblack px-3 py-1 rounded-full text-sm">
                    {
                      term.category.name[
                        language as keyof typeof term.category.name
                      ]
                    }
                  </span>
                )}
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="bg-gray-50 p-8 rounded-[16px] text-center">
          <p className="text-gray-600">{emptyText}</p>
        </div>
      )}
    </div>
  );
}
