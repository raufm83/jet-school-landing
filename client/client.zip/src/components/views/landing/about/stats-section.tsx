"use client";
import { motion } from "framer-motion";

interface StatsProps {
  stats: {
    graduatesLabel: string;
    groupsLabel: string;
    studentsLabel: string;
  };
}

export default function StatsSection({ stats }: StatsProps) {
  return (
    <section
      className="
        container
        max-w-[1720px] 4xl:max-w-[2560px]
        mx-auto
        py-8 md:py-14 4xl:py-20
      "
    >
      <div className="
        grid grid-cols-1 md:grid-cols-3
        gap-8 md:gap-10 2xl:gap-14 4xl:gap-20
      ">
        {[
          { value: "500+", label: stats.graduatesLabel },
          { value: "25+", label: stats.groupsLabel },
          { value: "200+", label: stats.studentsLabel },
        ].map(({ value, label }, index) => (
          <motion.div
            key={index}
            className="
              flex flex-col items-center justify-center
              text-center
              p-6 md:p-8 2xl:p-12 4xl:p-16
              bg-[#fef7eb]
              rounded-[32px]
              border border-jsyellow
              min-h-[140px] md:min-h-[170px] 2xl:min-h-[220px] 4xl:min-h-[260px]
            "
            whileHover={{ scale: 1.03 }}
          >
            <h3 className="text-2xl md:text-3xl 2xl:text-5xl 4xl:text-6xl font-bold text-jsyellow mb-2 4xl:mb-4">
              {value}
            </h3>
            <p className="text-base md:text-lg 2xl:text-xl 4xl:text-2xl text-gray-600">
              {label}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
