import { cn } from "@/utils/cn";
import Image from "next/image";
import { MdFullscreen } from "react-icons/md";

interface GalleryCardProps {
  imageUrl?: string;
  title?: string | null;
  isLoading?: boolean;
}

export default function GalleryCard({
  imageUrl,
  title,
  isLoading = false,
}: GalleryCardProps) {
  return (
    <div className="relative w-full h-[250px] cursor-pointer overflow-hidden rounded-3xl group">
      {isLoading ? (
        <div className="w-full h-full bg-gray-300 ease-in-out duration-200 animate-pulse rounded-3xl"></div>
      ) : (
        <div className="relative w-full h-full transition-transform duration-300 md:group-hover:scale-105">
          <Image
            src={`${process.env.NEXT_PUBLIC_CDN_URL}/${imageUrl}`}
            alt={title || "Gallery image"}
            fill
            className="object-cover rounded-3xl"
          />
        </div>
      )}
      {!isLoading && title && (
        <div
          className={cn(
            "absolute inset-x-0 bottom-0 md:flex h-[100%] bg-gradient-to-t from-black/50 to-black/30 hidden flex-col justify-center items-center px-6 backdrop-blur-sm transition-all duration-300 delay-[50ms]",
            "md:opacity-0 md:group-hover:opacity-100"
          )}
        >
          <div className="bg-jsyellow md:group-hover:opacity-100 opacity-0 transition-all duration-400 delay-75 ease-in-out px-8 py-8 justify-center w-fit text-3xl rounded-full flex items-center">
            <MdFullscreen />
          </div>
        </div>
      )}
    </div>
  );
}
