"use client";

import { useEffect, useState } from "react";
import SectionTitle from "@/components/shared/section-title";
import { Locale } from "@/i18n/request";
import { Course, CourseResponse } from "@/types/course";
import { getIcon } from "@/utils/icon";
import Link from "next/link";
import { FaClock, FaGraduationCap } from "react-icons/fa";
import { useTranslations } from "next-intl";

interface ICoursesSlider {
  courses: CourseResponse;
  locale?: Locale;
}

const CoursesSlider = ({ courses, locale = "az" }: ICoursesSlider) => {
  const t = useTranslations("courseInfo");
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const displayCourses = courses.items;
  if (!displayCourses) return null;

  const normalizedLocale = locale.slice(0, 2) as "az" | "ru";

  return (
    <div className="container mx-auto my-20 p-0">
      <SectionTitle title={t("title")} description={t("description")} />

      <div className="relative">
        {isClient ? (
          <div
            className="
              grid grid-cols-1 md:grid-cols-2
              gap-6 py-4
              4xl:gap-8 4xl:py-6
            "
          >
            {displayCourses.map((course: Course) => {
              const IconComponent = getIcon(course.icon);
              const tags =
                course.newTags?.[normalizedLocale] ??
                course.tag ??
                [];

              return (
                <Link
                  key={course.id}
                  href={`/${normalizedLocale}/course/${course.slug[normalizedLocale]}`}
                  className="
                    relative flex flex-col justify-between
                    w-full bg-[#fef7eb] border-2 border-jsyellow
                    rounded-[32px] overflow-hidden
                    p-6 4xl:p-8
                    transition-shadow hover:shadow-lg
                  "
                >
                  <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-jsyellow/10 to-transparent" />

                  <div className="relative flex flex-col gap-6 4xl:gap-8 z-10">
                    <div className="flex justify-end">
                      <div className="
                        flex items-center gap-2
                        bg-white border border-jsyellow/20
                        px-4 py-2 rounded-full text-sm
                      ">
                        <FaGraduationCap className="w-4 h-4 [@media(min-width:3500px)]:!w-8 [@media(min-width:3500px)]:!h-8 text-jsyellow" />
                        <span className="font-medium text-jsblack [@media(min-width:3500px)]:!text-xl">
                          {course.level[normalizedLocale]}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="
                        flex-shrink-0 w-12 h-12
                        bg-jsyellow text-white rounded-2xl
                        flex items-center justify-center
                      ">
                        <IconComponent className="w-6 h-6 [@media(min-width:3500px)]:!h-8 [@media(min-width:3500px)]:!w-8" />
                      </div>
                      <h2 className="text-2xl font-bold [@media(min-width:3500px)]:!text-3xl text-jsblack leading-tight">
                        {course.title[normalizedLocale]}
                      </h2>
                    </div>

                    {/* Tags */}
                    {tags.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2 text-xs">
                        {tags.map((tag, i) => (
                          <span
                            key={i}
                            className="
                              font-medium [@media(min-width:3500px)]:!text-xl bg-jsyellow/10 text-black
                              px-3 py-1 rounded-full
                            "
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Duration */}
                    <div className="
                      bg-white/60 backdrop-blur-sm
                      rounded-2xl p-4 border border-jsyellow/20
                      text-sm
                    ">
                      <div className="flex items-center gap-3">
                        <div className="
                          w-8 h-8 bg-jsyellow/10
                          rounded-full flex items-center justify-center
                        ">
                          <FaClock className="w-4 h-4 text-jsyellow [@media(min-width:3500px)]:!h-8 [@media(min-width:3500px)]:!w-8" />
                        </div>
                        <div>
                          <span className="text-gray-500 [@media(min-width:3500px)]:!text-2xl">
                            {normalizedLocale === "az" ? "Müddət" : "Длительность"}
                          </span>
                          <p className="font-medium [@media(min-width:3500px)]:!text-2xl">
                            {course.duration}{" "}
                            {normalizedLocale === "az" ? "ay" : "месяцев"}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-pulse">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-[280px] rounded-[32px] bg-gray-100"
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CoursesSlider;
