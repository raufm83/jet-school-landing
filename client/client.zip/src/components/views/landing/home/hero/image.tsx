"use client";
import { memo } from "react";
import Image from "next/image";

const HeroImageComponent = memo(function HeroImageComponent({
  src,
  width,
  className,
}: {
  src: string;
  width: number;
  className: string;
}) {
  return (
    <Image
      src={src}
      className={className}
      width={width}
      height={width}
      quality={90}
      alt="hero element"
      draggable={false}
      onDragStart={(e) => e.preventDefault()}
      priority={true}
    />
  );
});

export default function HeroImage() {
  return (
    <div
      className="
      w-[300px] h-[300px] 
      md:w-[400px] md:h-[400px] 
      lg:w-[457.28px] lg:h-[459px]
      [@media(min-width:3500px)]:!w-[700px]
      [@media(min-width:3500px)]:!h-[600px]
      relative 
      cursor-pointer 
      select-none 
      [background:linear-gradient(81.67deg,rgba(252,174,30,0.39)_12.42%,rgba(252,174,30,0.695)_42.61%,#FCAE1E_62.24%,rgba(252,174,30,0.8475)_72.81%)] 
      [box-shadow:0px_2px_8px_rgba(99,99,99,0.25)] 
      [border-radius:266.5px_32px_335px_266.5px] 
      shrink-0
      group
      transition-transform duration-300 ease-out
      hover:scale-[1.02]
    "
    >
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[2] w-full flex items-center justify-center">
        <HeroImageComponent
          src="/hero/laptop.png"
          width={392}
          className="w-[250px] md:w-[300px] lg:w-[392px] [@media(min-width:3500px)]:!w-[700px]  h-auto [filter:drop-shadow(0px_13px_21.2px_rgba(0,0,0,0.25))] transition-transform duration-300 group-hover:scale-[1.05]"
        />
      </div>

      <div className="absolute top-[80%] left-[65%] -translate-x-1/2 -translate-y-1/2 z-[3]">
        <HeroImageComponent
          src="/hero/cursor.png"
          width={144}
          className="w-[80px] md:w-[100px] lg:w-[144px] [@media(min-width:3500px)]:!w-[300px] h-auto [filter:drop-shadow(-3px_22px_19.9px_rgba(0,0,0,0.25))] transition-transform duration-300 group-hover:scale-110 group-hover:translate-x-2 group-hover:-translate-y-2"
        />
      </div>

      <div className="absolute top-[35%] left-[25%] -translate-x-1/2 -translate-y-1/2 z-[1]">
        <HeroImageComponent
          src="/hero/book.png"
          width={133}
          className="w-[80px] md:w-[100px] lg:w-[133px] h-auto [@media(min-width:3500px)]:!w-[300px] [filter:drop-shadow(-3px_22px_19.9px_rgba(0,0,0,0.25))] transition-transform duration-300 group-hover:scale-110 group-hover:-translate-x-2"
        />
      </div>

      <div className="absolute top-[80%] left-[10%] -translate-x-1/2 -translate-y-1/2 z-[3]">
        <HeroImageComponent
          src="/hero/camera.png"
          width={168}
          className="w-[100px] md:w-[120px] lg:w-[168px] h-auto [@media(min-width:3500px)]:!w-[300px] [filter:drop-shadow(0_16px_18.9px_rgba(0,0,0,0.25))] transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-2"
        />
      </div>
    </div>
  );
}
